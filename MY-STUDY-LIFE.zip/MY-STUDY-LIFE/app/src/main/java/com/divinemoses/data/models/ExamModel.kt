package com.example.mystudylife.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

@Entity(tableName = "exams")
data class ExamModel(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,
    val classId: Int,
    val className: String,
    val description: String,
    val examDate: Long, // Timestamp
    val startTime: String, // HH:mm format
    val endTime: String,   // HH:mm format
    val location: String,
    val examType: String, // "MIDTERM", "FINAL", "QUIZ", "OTHER"
    val syllabus: String? = null, // URL or file path
    val notes: String = "",
    val targetScore: Int? = null, // percentage
    val actualScore: Int? = null, // percentage
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val syncedToCloud: Boolean = false,
    val cloudId: String = ""
)
