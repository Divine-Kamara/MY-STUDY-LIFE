package com.example.mystudylife.utils

import android.content.Context
import android.os.Build
import androidx.core.content.ContextCompat
import android.Manifest

object PermissionUtils {
    
    // Sensor-related permissions
    const val BODY_SENSORS = Manifest.permission.BODY_SENSORS
    const val BODY_SENSORS_BACKGROUND = "android.permission.BODY_SENSORS_BACKGROUND"
    
    // Check if permission is granted
    fun isPermissionGranted(context: Context, permission: String): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            permission
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }
    
    // Check if all sensor permissions are granted
    fun areSensorPermissionsGranted(context: Context): Boolean {
        return isPermissionGranted(context, BODY_SENSORS)
    }
    
    // Get required permissions based on API level
    fun getRequiredSensorPermissions(): Array<String> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(BODY_SENSORS, BODY_SENSORS_BACKGROUND)
        } else {
            arrayOf(BODY_SENSORS)
        }
    }
    
    // Check if device has necessary sensors
    fun hasAccelerometer(context: Context): Boolean {
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? android.hardware.SensorManager
        return sensorManager?.getDefaultSensor(android.hardware.Sensor.TYPE_ACCELEROMETER) != null
    }
    
    fun hasLightSensor(context: Context): Boolean {
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? android.hardware.SensorManager
        return sensorManager?.getDefaultSensor(android.hardware.Sensor.TYPE_LIGHT) != null
    }
    
    fun hasProximitySensor(context: Context): Boolean {
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? android.hardware.SensorManager
        return sensorManager?.getDefaultSensor(android.hardware.Sensor.TYPE_PROXIMITY) != null
    }
}
