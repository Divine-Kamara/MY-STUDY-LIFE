package com.example.mystudylife.ui.activities

import android.os.Bundle
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.mystudylife.R
import com.example.mystudylife.data.models.ClassModel
import com.example.mystudylife.ui.viewmodels.ClassViewModel
import com.google.android.material.textfield.TextInputEditText
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class AddClassActivity : AppCompatActivity() {
    private val classViewModel: ClassViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_class)

        val classNameInput = findViewById<TextInputEditText>(R.id.input_class_name)
        val instructorInput = findViewById<TextInputEditText>(R.id.input_instructor)
        val locationInput = findViewById<TextInputEditText>(R.id.input_location)
        val startTimeInput = findViewById<TextInputEditText>(R.id.input_start_time)
        val endTimeInput = findViewById<TextInputEditText>(R.id.input_end_time)
        val daysSpinner = findViewById<Spinner>(R.id.spinner_days)
        val saveButton = findViewById<Button>(R.id.button_save_class)

        // Setup days spinner
        val daysOptions = arrayOf(
            "Select days...",
            "MON,WED,FRI",
            "TUE,THU",
            "MON,TUE,WED,THU,FRI",
            "EVERY_DAY"
        )
        setupSpinner(daysSpinner, daysOptions)

        saveButton.setOnClickListener {
            if (classNameInput.text.toString().isEmpty()) {
                Toast.makeText(this, "Please enter class name", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val classModel = ClassModel(
                className = classNameInput.text.toString().trim(),
                instructor = instructorInput.text.toString().trim(),
                location = locationInput.text.toString().trim(),
                startTime = startTimeInput.text.toString().trim(),
                endTime = endTimeInput.text.toString().trim(),
                daysOfWeek = daysSpinner.selectedItem.toString()
            )

            classViewModel.insertClass(classModel)
            Toast.makeText(this, getString(R.string.msg_class_saved), Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun setupSpinner(spinner: Spinner, options: Array<String>) {
        val adapter = android.widget.ArrayAdapter(this, android.R.layout.simple_spinner_item, options)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
    }
}
