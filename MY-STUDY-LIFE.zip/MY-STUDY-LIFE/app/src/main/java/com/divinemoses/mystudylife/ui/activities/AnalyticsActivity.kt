package com.divinemoses.mystudylife.ui.activities

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet
import com.divinemoses.mystudylife.R
import com.divinemoses.mystudylife.ui.viewmodels.AnalyticsViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class AnalyticsActivity : AppCompatActivity() {
    
    private val analyticsViewModel: AnalyticsViewModel by viewModels()
    
    private lateinit var loadingProgress: ProgressBar
    private lateinit var contentView: View
    
    private lateinit var statsContainer: View
    private lateinit var totalSessionsText: TextView
    private lateinit var avgQualityText: TextView
    private lateinit var bestScoreText: TextView
    private lateinit var totalTimeText: TextView
    
    private lateinit var focusTrendChart: LineChart
    private lateinit var sessionFrequencyChart: BarChart
    
    private lateinit var backButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_analytics)

        initializeViews()
        observeAnalytics()
    }

    private fun initializeViews() {
        loadingProgress = findViewById(R.id.progress_loading)
        contentView = findViewById(R.id.content_analytics)
        
        // Stats
        statsContainer = findViewById(R.id.container_stats)
        totalSessionsText = findViewById(R.id.text_total_sessions)
        avgQualityText = findViewById(R.id.text_avg_quality)
        bestScoreText = findViewById(R.id.text_best_score)
        totalTimeText = findViewById(R.id.text_total_time)
        
        // Charts
        focusTrendChart = findViewById(R.id.chart_focus_trend)
        sessionFrequencyChart = findViewById(R.id.chart_session_frequency)
        
        backButton = findViewById(R.id.button_back)
        backButton.setOnClickListener { finish() }
        
        // Configure charts
        configureFocusTrendChart()
        configureSessionFrequencyChart()
    }

    private fun observeAnalytics() {
        lifecycleScope.launch {
            analyticsViewModel.isLoading.collect { isLoading ->
                loadingProgress.visibility = if (isLoading) View.VISIBLE else View.GONE
                contentView.visibility = if (isLoading) View.GONE else View.VISIBLE
            }
        }

        lifecycleScope.launch {
            analyticsViewModel.analyticsData.collect { analytics ->
                // Update stats
                totalSessionsText.text = "${analytics.totalSessions} sessions"
                avgQualityText.text = "${analytics.averageQualityScore}%"
                bestScoreText.text = "${analytics.bestQualityScore}% (Best: ${analytics.worstQualityScore}% Worst)"
                totalTimeText.text = "${analytics.totalStudyTime} minutes"
                
                // Update charts
                updateFocusTrendChart(analytics.focusLevelTrend)
                updateSessionFrequencyChart(analytics.sessionsByDay)
            }
        }
    }

    private fun configureFocusTrendChart() {
        focusTrendChart.apply {
            description.isEnabled = false
            setTouchEnabled(true)
            setDragEnabled(true)
            setScaleEnabled(true)
            xAxis.setDrawGridLines(false)
            axisLeft.setDrawGridLines(true)
            axisRight.isEnabled = false
            legend.isEnabled = true
        }
    }

    private fun configureSessionFrequencyChart() {
        sessionFrequencyChart.apply {
            description.isEnabled = false
            setTouchEnabled(true)
            setDragEnabled(true)
            setScaleEnabled(true)
            xAxis.setDrawGridLines(false)
            axisLeft.setDrawGridLines(true)
            axisRight.isEnabled = false
            legend.isEnabled = true
        }
    }

    private fun updateFocusTrendChart(focusTrend: List<Pair<String, Float>>) {
        if (focusTrend.isEmpty()) return
        
        val entries = focusTrend.mapIndexed { index, (_, value) ->
            Entry(index.toFloat(), value)
        }
        
        val dataSet = LineDataSet(entries, "Study Quality Score (%)").apply {
            color = android.graphics.Color.parseColor("#6200EE")
            setCircleColor(android.graphics.Color.parseColor("#6200EE"))
            lineWidth = 2f
            circleRadius = 4f
            valueTextSize = 10f
            mode = LineDataSet.Mode.CUBIC_BEZIER
        }
        
        val lineData = LineData(dataSet)
        focusTrendChart.apply {
            data = lineData
            invalidate()
        }
    }

    private fun updateSessionFrequencyChart(sessionsByDay: Map<String, Int>) {
        if (sessionsByDay.isEmpty()) return
        
        val entries = sessionsByDay.toList()
            .sortedByDescending { it.first }
            .take(7) // Last 7 days
            .mapIndexed { index, (_, count) ->
                BarEntry(index.toFloat(), count.toFloat())
            }
        
        val dataSet = BarDataSet(entries, "Study Sessions").apply {
            color = android.graphics.Color.parseColor("#03DAC6")
            valueTextSize = 10f
        }
        
        val barData = BarData(dataSet)
        sessionFrequencyChart.apply {
            data = barData
            invalidate()
        }
    }
}
