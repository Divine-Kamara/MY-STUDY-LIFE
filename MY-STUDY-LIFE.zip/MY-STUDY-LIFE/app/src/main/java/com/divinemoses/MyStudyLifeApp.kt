package com.example.mystudylife

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MyStudyLifeApp : Application()