package com.divinemoses.mystudylife.ui.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.divinemoses.mystudylife.data.models.ClassModel
import com.divinemoses.mystudylife.databinding.ItemClassBinding

class ClassAdapter(
    private val classes: List<ClassModel>,
    private val onClassClick: (ClassModel) -> Unit,
    private val onDeleteClick: (ClassModel) -> Unit
) : RecyclerView.Adapter<ClassAdapter.ClassViewHolder>() {

    inner class ClassViewHolder(private val binding: ItemClassBinding) :
        RecyclerView.ViewHolder(binding.root) {
        
        fun bind(classItem: ClassModel) {
            binding.apply {
                textClassName.text = classItem.className
                textInstructor.text = "Instructor: ${classItem.instructor}"
                textLocation.text = "Location: ${classItem.location}"
                textTime.text = "${classItem.startTime} - ${classItem.endTime}"
                textDays.text = "Days: ${classItem.daysOfWeek}"
                
                cardClass.setCardBackgroundColor(
                    android.graphics.Color.parseColor(classItem.color)
                )
                
                root.setOnClickListener {
                    onClassClick(classItem)
                }
                
                buttonDelete.setOnClickListener {
                    onDeleteClick(classItem)
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ClassViewHolder {
        val binding = ItemClassBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ClassViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ClassViewHolder, position: Int) {
        holder.bind(classes[position])
    }

    override fun getItemCount(): Int = classes.size
}
