package com.divinemoses.mystudylife.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.divinemoses.mystudylife.data.models.StudySessionModel
import com.divinemoses.mystudylife.domain.repositories.StudySessionRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import kotlin.math.round

data class AnalyticsData(
    val totalSessions: Int = 0,
    val averageQualityScore: Float = 0f,
    val bestQualityScore: Int = 0,
    val worstQualityScore: Int = 100,
    val totalStudyTime: Long = 0L, // in minutes
    val sessionsByDay: Map<String, Int> = emptyMap(),
    val qualityScoresByDay: Map<String, Float> = emptyMap(),
    val focusLevelTrend: List<Pair<String, Float>> = emptyList(),
    val topStudyHours: List<String> = emptyList()
)

@HiltViewModel
class AnalyticsViewModel @Inject constructor(
    private val studySessionRepository: StudySessionRepository
) : ViewModel() {
    
    private val _analyticsData = MutableStateFlow(AnalyticsData())
    val analyticsData: StateFlow<AnalyticsData> = _analyticsData.asStateFlow()
    
    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    init {
        loadAnalytics()
    }

    fun loadAnalytics() {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                studySessionRepository.getAllSessions().collect { sessions ->
                    val analytics = calculateAnalytics(sessions)
                    _analyticsData.value = analytics
                    _isLoading.value = false
                }
            } catch (e: Exception) {
                _isLoading.value = false
            }
        }
    }

    private fun calculateAnalytics(sessions: List<StudySessionModel>): AnalyticsData {
        if (sessions.isEmpty()) {
            return AnalyticsData()
        }

        val totalSessions = sessions.size
        val averageQuality = sessions.map { it.studyQualityScore }.average().toFloat()
        val bestQuality = sessions.maxOf { it.studyQualityScore }
        val worstQuality = sessions.minOf { it.studyQualityScore }
        val totalTime = sessions.sumOf { (it.endTime - it.startTime) / 60000 } // convert ms to minutes

        // Group by day
        val sessionsByDay = sessions.groupingBy { formatDate(it.startTime) }
            .eachCount()

        val qualityScoresByDay = sessions.groupBy { formatDate(it.startTime) }
            .mapValues { (_, daySessions) ->
                daySessions.map { it.studyQualityScore }.average().toFloat()
            }

        // Get top study hours
        val hourCounts = sessions.groupingBy { getHourOfDay(it.startTime) }
            .eachCount()
            .toList()
            .sortedByDescending { it.second }
            .take(3)
            .map { (hour, _) -> "$hour:00" }

        // Calculate focus level trend (last 10 sessions)
        val focusTrend = sessions.takeLast(10)
            .mapIndexed { index, session ->
                "Session ${index + 1}" to session.studyQualityScore.toFloat()
            }

        return AnalyticsData(
            totalSessions = totalSessions,
            averageQualityScore = round(averageQuality * 10) / 10,
            bestQualityScore = bestQuality,
            worstQualityScore = worstQuality,
            totalStudyTime = totalTime,
            sessionsByDay = sessionsByDay,
            qualityScoresByDay = qualityScoresByDay,
            focusLevelTrend = focusTrend,
            topStudyHours = hourCounts
        )
    }

    private fun formatDate(timestamp: Long): String {
        val dateFormat = java.text.SimpleDateFormat("MMM dd", java.util.Locale.getDefault())
        return dateFormat.format(java.util.Date(timestamp))
    }

    private fun getHourOfDay(timestamp: Long): Int {
        val calendar = java.util.Calendar.getInstance()
        calendar.timeInMillis = timestamp
        return calendar.get(java.util.Calendar.HOUR_OF_DAY)
    }
}
