package com.divinemoses.mystudylife.ui.activities

import android.os.Bundle
import android.widget.Button
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.divinemoses.mystudylife.R
import com.divinemoses.mystudylife.ui.adapters.HomeworkAdapter
import com.divinemoses.mystudylife.ui.viewmodels.HomeworkViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class ListHomeworkActivity : AppCompatActivity() {
    private val homeworkViewModel: HomeworkViewModel by viewModels()
    private lateinit var recyclerView: RecyclerView
    private lateinit var backButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_homework)

        recyclerView = findViewById(R.id.recycler_homework)
        backButton = findViewById(R.id.button_back)

        recyclerView.layoutManager = LinearLayoutManager(this)

        backButton.setOnClickListener {
            finish()
        }

        lifecycleScope.launch {
            homeworkViewModel.homeworkList.collect { homework ->
                val adapter = HomeworkAdapter(
                    homework = homework,
                    onHomeworkClick = { homeworkItem ->
                        // Handle homework click - could show detail or edit screen
                    },
                    onDeleteClick = { homeworkItem ->
                        homeworkViewModel.deleteHomework(homeworkItem)
                    },
                    onCompleteClick = { homeworkItem ->
                        // Handle complete click - could mark as done
                    }
                )
                recyclerView.adapter = adapter
            }
        }
    }
}
