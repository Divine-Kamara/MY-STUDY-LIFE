package com.example.mystudylife.sensors

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager

/**
 * Proximity Sensor Manager
 * 
 * Purpose: Detects if device is being held close to the face/body
 * Use Cases:
 * - Detect if student is actively using the app (proximity to face = active)
 * - Measure screen-on time during study sessions
 * - Track device usage patterns
 * - Pause notifications when phone is in pocket/bag
 * 
 * Data collected: Distance to object (typically 0 = close, higher = far)
 */
class ProximitySensorManager(private val context: Context) : SensorEventListener {
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val proximitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY)
    
    private var isDeviceNearFace = false
    private var lastProximityValue = 0f
    
    var onProximityChanged: ((isNear: Boolean) -> Unit)? = null
    var onDeviceLiftedUp: (() -> Unit)? = null
    var onDevicePutDown: (() -> Unit)? = null
    
    fun startListening() {
        proximitySensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }
    
    fun stopListening() {
        sensorManager.unregisterListener(this)
    }
    
    override fun onSensorChanged(event: SensorEvent?) {
        event?.let {
            if (event.sensor.type == Sensor.TYPE_PROXIMITY) {
                val distance = event.values[0]
                val maxRange = event.sensor.maximumRange
                
                val wasNear = isDeviceNearFace
                isDeviceNearFace = distance < maxRange / 2
                
                // Detect state changes
                if (isDeviceNearFace && !wasNear) {
                    onDeviceLiftedUp?.invoke() // Student picked up device
                } else if (!isDeviceNearFace && wasNear) {
                    onDevicePutDown?.invoke() // Student put device down
                }
                
                onProximityChanged?.invoke(isDeviceNearFace)
                lastProximityValue = distance
            }
        }
    }
    
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    
    fun isDeviceNearUser(): Boolean = isDeviceNearFace
    
    fun getStudyEngagement(): String {
        return when {
            isDeviceNearFace -> "ACTIVELY_STUDYING" // Device near = using it
            else -> "INACTIVE" // Device away = not using it
        }
    }
}
