package com.example.mystudylife.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "study_sessions")
data class StudySessionModel(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val classId: Int,
    val className: String,
    val startTime: Long,
    val endTime: Long? = null,
    val focusLevelAverage: Float = 0f, // Aggregated from accelerometer
    val lightingQualityAverage: String = "OPTIMAL", // Aggregated from light sensor
    val engagementRate: Float = 0f, // Percentage from proximity sensor
    val studyQualityScore: Int = 0, // 0-100 based on all sensors
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
