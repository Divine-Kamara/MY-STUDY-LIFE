package com.example.mystudylife.data.local

import androidx.room.*
import com.example.mystudylife.data.models.ClassModel
import kotlinx.coroutines.flow.Flow

@Dao
interface ClassDao {
    
    // INSERT
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClass(classModel: ClassModel): Long
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClasses(classes: List<ClassModel>)
    
    // READ
    @Query("SELECT * FROM classes ORDER BY className ASC")
    fun getAllClasses(): Flow<List<ClassModel>>
    
    @Query("SELECT * FROM classes WHERE id = :classId")
    suspend fun getClassById(classId: Int): ClassModel?
    
    @Query("SELECT * FROM classes WHERE cloudId = :cloudId")
    suspend fun getClassByCloudId(cloudId: String): ClassModel?
    
    @Query("SELECT * FROM classes WHERE syncedToCloud = 0")
    suspend fun getUnsyncedClasses(): List<ClassModel>
    
    // UPDATE
    @Update
    suspend fun updateClass(classModel: ClassModel)
    
    @Query("UPDATE classes SET syncedToCloud = 1, cloudId = :cloudId WHERE id = :classId")
    suspend fun markClassAsSynced(classId: Int, cloudId: String)
    
    // DELETE
    @Delete
    suspend fun deleteClass(classModel: ClassModel)
    
    @Query("DELETE FROM classes WHERE id = :classId")
    suspend fun deleteClassById(classId: Int)
    
    @Query("DELETE FROM classes")
    suspend fun deleteAllClasses()
}
