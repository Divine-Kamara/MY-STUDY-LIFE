package com.example.mystudylife.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

@Entity(tableName = "classes")
data class ClassModel(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val className: String,
    val instructor: String,
    val location: String,
    val startTime: String, // HH:mm format
    val endTime: String,   // HH:mm format
    val daysOfWeek: String, // "MON,WED,FRI"
    val description: String = "",
    val color: String = "#FF6200EE", // Material color
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val syncedToCloud: Boolean = false,
    val cloudId: String = ""
)
