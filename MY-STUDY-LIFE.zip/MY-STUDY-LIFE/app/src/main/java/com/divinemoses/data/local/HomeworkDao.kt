package com.example.mystudylife.data.local

import androidx.room.*
import com.example.mystudylife.data.models.HomeworkModel
import kotlinx.coroutines.flow.Flow

@Dao
interface HomeworkDao {
    
    // INSERT
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHomework(homeworkModel: HomeworkModel): Long
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHomeworkList(homework: List<HomeworkModel>)
    
    // READ
    @Query("SELECT * FROM homework ORDER BY dueDate ASC")
    fun getAllHomework(): Flow<List<HomeworkModel>>
    
    @Query("SELECT * FROM homework WHERE id = :homeworkId")
    suspend fun getHomeworkById(homeworkId: Int): HomeworkModel?
    
    @Query("SELECT * FROM homework WHERE cloudId = :cloudId")
    suspend fun getHomeworkByCloudId(cloudId: String): HomeworkModel?
    
    @Query("SELECT * FROM homework WHERE classId = :classId ORDER BY dueDate ASC")
    fun getHomeworkByClass(classId: Int): Flow<List<HomeworkModel>>
    
    @Query("SELECT * FROM homework WHERE isCompleted = 0 ORDER BY dueDate ASC")
    fun getPendingHomework(): Flow<List<HomeworkModel>>
    
    @Query("SELECT * FROM homework WHERE isCompleted = 1")
    fun getCompletedHomework(): Flow<List<HomeworkModel>>
    
    @Query("SELECT * FROM homework WHERE priority = :priority ORDER BY dueDate ASC")
    fun getHomeworkByPriority(priority: String): Flow<List<HomeworkModel>>
    
    @Query("SELECT * FROM homework WHERE syncedToCloud = 0")
    suspend fun getUnsyncedHomework(): List<HomeworkModel>
    
    // UPDATE
    @Update
    suspend fun updateHomework(homeworkModel: HomeworkModel)
    
    @Query("UPDATE homework SET isCompleted = 1, completedDate = :completedDate WHERE id = :homeworkId")
    suspend fun markHomeworkAsComplete(homeworkId: Int, completedDate: Long)
    
    @Query("UPDATE homework SET syncedToCloud = 1, cloudId = :cloudId WHERE id = :homeworkId")
    suspend fun markHomeworkAsSynced(homeworkId: Int, cloudId: String)
    
    // DELETE
    @Delete
    suspend fun deleteHomework(homeworkModel: HomeworkModel)
    
    @Query("DELETE FROM homework WHERE id = :homeworkId")
    suspend fun deleteHomeworkById(homeworkId: Int)
    
    @Query("DELETE FROM homework WHERE classId = :classId")
    suspend fun deleteHomeworkByClass(classId: Int)
    
    @Query("DELETE FROM homework")
    suspend fun deleteAllHomework()
}
