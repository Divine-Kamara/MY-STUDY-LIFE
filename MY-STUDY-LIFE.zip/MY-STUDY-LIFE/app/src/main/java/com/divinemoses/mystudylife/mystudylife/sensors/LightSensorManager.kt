package com.example.mystudylife.sensors

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager

/**
 * Light Sensor Manager
 * 
 * Purpose: Monitors ambient light levels in the study environment
 * Use Cases:
 * - Track study environment quality (well-lit vs dim)
 * - Send reminder if lighting is too dark (eye strain warning)
 * - Analyze productivity patterns based on lighting conditions
 * - Ensure optimal study environment
 * 
 * Data collected: Light intensity in lux (lumens per square meter)
 */
class LightSensorManager(private val context: Context) : SensorEventListener {
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)
    
    private var currentLux = 0f
    
    // Lighting level thresholds (standard lux ranges)
    private val optimalLuxMin = 300f  // Minimum for comfortable reading
    private val optimalLuxMax = 500f  // Maximum to avoid glare
    private val dimLuxThreshold = 100f // Too dark warning
    private val brightLuxThreshold = 1000f // Too bright warning
    
    var onLightingChanged: ((lux: Float, quality: String) -> Unit)? = null
    var onDarkWarning: (() -> Unit)? = null
    var onBrightWarning: (() -> Unit)? = null
    
    fun startListening() {
        lightSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }
    
    fun stopListening() {
        sensorManager.unregisterListener(this)
    }
    
    override fun onSensorChanged(event: SensorEvent?) {
        event?.let {
            if (event.sensor.type == Sensor.TYPE_LIGHT) {
                currentLux = event.values[0]
                
                val quality = getLightingQuality()
                onLightingChanged?.invoke(currentLux, quality)
                
                // Warnings for poor lighting
                if (currentLux < dimLuxThreshold) {
                    onDarkWarning?.invoke()
                }
                
                if (currentLux > brightLuxThreshold) {
                    onBrightWarning?.invoke()
                }
            }
        }
    }
    
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    
    fun getCurrentLux(): Float = currentLux
    
    fun getLightingQuality(): String {
        return when {
            currentLux < dimLuxThreshold -> "TOO_DARK"
            currentLux < optimalLuxMin -> "DIM"
            currentLux <= optimalLuxMax -> "OPTIMAL"
            currentLux < brightLuxThreshold -> "BRIGHT"
            else -> "TOO_BRIGHT"
        }
    }
    
    fun isOptimalLighting(): Boolean {
        return currentLux in optimalLuxMin..optimalLuxMax
    }
}
