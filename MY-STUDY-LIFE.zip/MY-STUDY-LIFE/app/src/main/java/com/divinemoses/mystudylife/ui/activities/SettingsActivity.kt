package com.divinemoses.mystudylife.ui.activities

import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.divinemoses.mystudylife.R
import com.divinemoses.mystudylife.ui.viewmodels.SettingsViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class SettingsActivity : AppCompatActivity() {
    
    private val settingsViewModel: SettingsViewModel by viewModels()
    
    private lateinit var accelerometerSlider: SeekBar
    private lateinit var lightSlider: SeekBar
    private lateinit var proximitySlider: SeekBar
    private lateinit var accelerometerValue: TextView
    private lateinit var lightValue: TextView
    private lateinit var proximityValue: TextView
    
    private lateinit var autoSyncCheckbox: CheckBox
    private lateinit var syncOnWifiCheckbox: CheckBox
    private lateinit var notificationsCheckbox: CheckBox
    private lateinit var syncFrequencySpinner: Spinner
    
    private lateinit var resetButton: Button
    private lateinit var backButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        initializeViews()
        setupListeners()
        observeSettings()
    }

    private fun initializeViews() {
        // Sensor Sliders
        accelerometerSlider = findViewById(R.id.slider_accelerometer)
        lightSlider = findViewById(R.id.slider_light)
        proximitySlider = findViewById(R.id.slider_proximity)
        
        accelerometerValue = findViewById(R.id.text_accelerometer_value)
        lightValue = findViewById(R.id.text_light_value)
        proximityValue = findViewById(R.id.text_proximity_value)
        
        // Sync Options
        autoSyncCheckbox = findViewById(R.id.checkbox_auto_sync)
        syncOnWifiCheckbox = findViewById(R.id.checkbox_sync_wifi_only)
        notificationsCheckbox = findViewById(R.id.checkbox_notifications)
        syncFrequencySpinner = findViewById(R.id.spinner_sync_frequency)
        
        // Buttons
        resetButton = findViewById(R.id.button_reset)
        backButton = findViewById(R.id.button_back)
        
        // Setup sync frequency spinner
        val syncFrequencyOptions = arrayOf(
            "Every 15 minutes (900s)",
            "Every 30 minutes (1800s)",
            "Every 1 hour (3600s)",
            "Every 2 hours (7200s)",
            "Every 4 hours (14400s)"
        )
        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, syncFrequencyOptions)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        syncFrequencySpinner.adapter = spinnerAdapter
    }

    private fun setupListeners() {
        accelerometerSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    settingsViewModel.updateAccelerometerSensitivity(progress)
                    accelerometerValue.text = progress.toString()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        lightSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    settingsViewModel.updateLightSensitivity(progress)
                    lightValue.text = progress.toString()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        proximitySlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    settingsViewModel.updateProximitySensitivity(progress)
                    proximityValue.text = progress.toString()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        autoSyncCheckbox.setOnCheckedChangeListener { _, isChecked ->
            settingsViewModel.updateAutoSyncEnabled(isChecked)
            syncFrequencySpinner.isEnabled = isChecked
        }

        syncOnWifiCheckbox.setOnCheckedChangeListener { _, isChecked ->
            settingsViewModel.updateSyncOnWifiOnly(isChecked)
        }

        notificationsCheckbox.setOnCheckedChangeListener { _, isChecked ->
            settingsViewModel.updateNotificationsEnabled(isChecked)
        }

        syncFrequencySpinner.setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                val frequency = when (position) {
                    0 -> 900
                    1 -> 1800
                    2 -> 3600
                    3 -> 7200
                    else -> 14400
                }
                settingsViewModel.updateSyncFrequency(frequency)
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        })

        resetButton.setOnClickListener {
            settingsViewModel.resetToDefaults()
        }

        backButton.setOnClickListener {
            finish()
        }
    }

    private fun observeSettings() {
        lifecycleScope.launch {
            settingsViewModel.settingsState.collect { settings ->
                // Update sliders
                accelerometerSlider.progress = settings.accelerometerSensitivity
                lightSlider.progress = settings.lightSensitivity
                proximitySlider.progress = settings.proximitySensitivity
                
                accelerometerValue.text = settings.accelerometerSensitivity.toString()
                lightValue.text = settings.lightSensitivity.toString()
                proximityValue.text = settings.proximitySensitivity.toString()
                
                // Update checkboxes
                autoSyncCheckbox.isChecked = settings.autoSyncEnabled
                syncOnWifiCheckbox.isChecked = settings.syncOnWifiOnly
                notificationsCheckbox.isChecked = settings.notificationsEnabled
                
                // Update spinner
                val frequencyPosition = when (settings.syncFrequency) {
                    900 -> 0
                    1800 -> 1
                    3600 -> 2
                    7200 -> 3
                    14400 -> 4
                    else -> 2
                }
                syncFrequencySpinner.setSelection(frequencyPosition)
            }
        }
    }
}
