package com.example.mystudylife.data.repositories

import com.example.mystudylife.data.local.ClassDao
import com.example.mystudylife.data.models.ClassModel
import com.example.mystudylife.domain.repositories.ClassRepository
import kotlinx.coroutines.flow.Flow

class ClassRepositoryImpl(
    private val classDao: ClassDao
) : ClassRepository {
    override suspend fun insertClass(classModel: ClassModel): Long {
        return classDao.insertClass(classModel)
    }

    override suspend fun insertClasses(classes: List<ClassModel>) {
        classDao.insertClasses(classes)
    }

    override fun getAllClasses(): Flow<List<ClassModel>> {
        return classDao.getAllClasses()
    }

    override suspend fun getClassById(classId: Int): ClassModel? {
        return classDao.getClassById(classId)
    }

    override suspend fun getUnsyncedClasses(): List<ClassModel> {
        return classDao.getUnsyncedClasses()
    }

    override suspend fun updateClass(classModel: ClassModel) {
        classDao.updateClass(classModel)
    }

    override suspend fun markClassAsSynced(classId: Int, cloudId: String) {
        classDao.markClassAsSynced(classId, cloudId)
    }

    override suspend fun deleteClass(classModel: ClassModel) {
        classDao.deleteClass(classModel)
    }

    override suspend fun deleteClassById(classId: Int) {
        classDao.deleteClassById(classId)
    }

    override suspend fun deleteAllClasses() {
        classDao.deleteAllClasses()
    }
}
