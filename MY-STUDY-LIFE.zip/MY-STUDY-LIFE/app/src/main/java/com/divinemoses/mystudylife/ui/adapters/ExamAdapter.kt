package com.divinemoses.mystudylife.ui.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.divinemoses.mystudylife.data.models.ExamModel
import com.divinemoses.mystudylife.databinding.ItemExamBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ExamAdapter(
    private val exams: List<ExamModel>,
    private val onExamClick: (ExamModel) -> Unit,
    private val onDeleteClick: (ExamModel) -> Unit
) : RecyclerView.Adapter<ExamAdapter.ExamViewHolder>() {

    inner class ExamViewHolder(private val binding: ItemExamBinding) :
        RecyclerView.ViewHolder(binding.root) {
        
        fun bind(exam: ExamModel) {
            binding.apply {
                textExamName.text = exam.examName
                textCourse.text = "Course: ${exam.courseCode}"
                textExamType.text = "Type: ${exam.examType}"
                
                val dateFormat = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
                textExamDate.text = "Date: ${dateFormat.format(Date(exam.examDate))}"
                textLocation.text = "Location: ${exam.location}"
                
                textExpectedScore.text = "Expected: ${exam.expectedScore}%"
                if (exam.actualScore != 0) {
                    textActualScore.text = "Actual: ${exam.actualScore}%"
                } else {
                    textActualScore.text = "Actual: Not graded"
                }
                
                root.setOnClickListener {
                    onExamClick(exam)
                }
                
                buttonDelete.setOnClickListener {
                    onDeleteClick(exam)
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExamViewHolder {
        val binding = ItemExamBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ExamViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ExamViewHolder, position: Int) {
        holder.bind(exams[position])
    }

    override fun getItemCount(): Int = exams.size
}
