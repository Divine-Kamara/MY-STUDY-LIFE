package com.example.mystudylife.di

import android.content.Context
import androidx.room.Room
import com.example.mystudylife.data.local.AppDatabase
import com.example.mystudylife.data.local.ClassDao
import com.example.mystudylife.data.local.ExamDao
import com.example.mystudylife.data.local.HomeworkDao
import com.example.mystudylife.data.local.StudySessionDao
import com.example.mystudylife.data.repositories.ClassRepositoryImpl
import com.example.mystudylife.data.repositories.ExamRepositoryImpl
import com.example.mystudylife.data.repositories.HomeworkRepositoryImpl
import com.example.mystudylife.data.repositories.StudySessionRepositoryImpl
import com.example.mystudylife.domain.repositories.ClassRepository
import com.example.mystudylife.domain.repositories.ExamRepository
import com.example.mystudylife.domain.repositories.HomeworkRepository
import com.example.mystudylife.domain.repositories.StudySessionRepository
import com.example.mystudylife.sensors.SensorDataManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides
    @Singleton
    fun provideAppDatabase(@ApplicationContext context: Context): AppDatabase {
        return Room.databaseBuilder(
            context.applicationContext,
            AppDatabase::class.java,
            "mystudylife_database"
        )
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides
    fun provideClassDao(database: AppDatabase): ClassDao = database.classDao()

    @Provides
    fun provideHomeworkDao(database: AppDatabase): HomeworkDao = database.homeworkDao()

    @Provides
    fun provideExamDao(database: AppDatabase): ExamDao = database.examDao()

    @Provides
    fun provideStudySessionDao(database: AppDatabase): StudySessionDao = database.studySessionDao()

    @Provides
    @Singleton
    fun provideClassRepository(classDao: ClassDao): ClassRepository {
        return ClassRepositoryImpl(classDao)
    }

    @Provides
    @Singleton
    fun provideHomeworkRepository(homeworkDao: HomeworkDao): HomeworkRepository {
        return HomeworkRepositoryImpl(homeworkDao)
    }

    @Provides
    @Singleton
    fun provideExamRepository(examDao: ExamDao): ExamRepository {
        return ExamRepositoryImpl(examDao)
    }

    @Provides
    @Singleton
    fun provideStudySessionRepository(studySessionDao: StudySessionDao): StudySessionRepository {
        return StudySessionRepositoryImpl(studySessionDao)
    }

    @Provides
    @Singleton
    fun provideSensorDataManager(@ApplicationContext context: Context): SensorDataManager {
        return SensorDataManager(context)
    }

    }
}
