package com.example.mystudylife.data.repositories

import com.example.mystudylife.data.local.HomeworkDao
import com.example.mystudylife.data.models.HomeworkModel
import com.example.mystudylife.domain.repositories.HomeworkRepository
import kotlinx.coroutines.flow.Flow

class HomeworkRepositoryImpl(
    private val homeworkDao: HomeworkDao
) : HomeworkRepository {
    override suspend fun insertHomework(homeworkModel: HomeworkModel): Long {
        return homeworkDao.insertHomework(homeworkModel)
    }

    override suspend fun insertHomeworkList(homework: List<HomeworkModel>) {
        homeworkDao.insertHomeworkList(homework)
    }

    override fun getAllHomework(): Flow<List<HomeworkModel>> {
        return homeworkDao.getAllHomework()
    }

    override suspend fun getHomeworkById(homeworkId: Int): HomeworkModel? {
        return homeworkDao.getHomeworkById(homeworkId)
    }

    override fun getHomeworkByClass(classId: Int): Flow<List<HomeworkModel>> {
        return homeworkDao.getHomeworkByClass(classId)
    }

    override fun getPendingHomework(): Flow<List<HomeworkModel>> {
        return homeworkDao.getPendingHomework()
    }

    override fun getCompletedHomework(): Flow<List<HomeworkModel>> {
        return homeworkDao.getCompletedHomework()
    }

    override fun getHomeworkByPriority(priority: String): Flow<List<HomeworkModel>> {
        return homeworkDao.getHomeworkByPriority(priority)
    }

    override suspend fun getUnsyncedHomework(): List<HomeworkModel> {
        return homeworkDao.getUnsyncedHomework()
    }

    override suspend fun updateHomework(homeworkModel: HomeworkModel) {
        homeworkDao.updateHomework(homeworkModel)
    }

    override suspend fun markHomeworkAsComplete(homeworkId: Int, completedDate: Long) {
        homeworkDao.markHomeworkAsComplete(homeworkId, completedDate)
    }

    override suspend fun markHomeworkAsSynced(homeworkId: Int, cloudId: String) {
        homeworkDao.markHomeworkAsSynced(homeworkId, cloudId)
    }

    override suspend fun deleteHomework(homeworkModel: HomeworkModel) {
        homeworkDao.deleteHomework(homeworkModel)
    }

    override suspend fun deleteHomeworkById(homeworkId: Int) {
        homeworkDao.deleteHomeworkById(homeworkId)
    }

    override suspend fun deleteHomeworkByClass(classId: Int) {
        homeworkDao.deleteHomeworkByClass(classId)
    }

    override suspend fun deleteAllHomework() {
        homeworkDao.deleteAllHomework()
    }
}
