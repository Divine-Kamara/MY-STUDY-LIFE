package com.example.mystudylife.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.mystudylife.data.models.ClassModel
import com.example.mystudylife.data.models.ExamModel
import com.example.mystudylife.data.models.HomeworkModel
import com.example.mystudylife.data.models.StudySessionModel

@Database(
    entities = [ClassModel::class, HomeworkModel::class, ExamModel::class, StudySessionModel::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    
    // DAO References
    abstract fun classDao(): ClassDao
    abstract fun homeworkDao(): HomeworkDao
    abstract fun examDao(): ExamDao
    abstract fun studySessionDao(): StudySessionDao
    
    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null
        
        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mystudylife_database"
                )
                    .fallbackToDestructiveMigration() // For development only!
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
