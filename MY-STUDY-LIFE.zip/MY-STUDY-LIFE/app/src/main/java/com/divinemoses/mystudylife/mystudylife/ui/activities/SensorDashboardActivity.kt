package com.example.mystudylife.ui.activities

import android.os.Bundle
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.mystudylife.R
import com.example.mystudylife.ui.viewmodels.SensorDashboardViewModel
import com.google.android.material.card.MaterialCardView
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class SensorDashboardActivity : AppCompatActivity() {
    private val viewModel: SensorDashboardViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sensor_dashboard)

        // Find views
        val qualityScoreText = findViewById<TextView>(R.id.text_quality_score)
        val qualityScoreProgress = findViewById<ProgressBar>(R.id.progress_quality_score)
        val focusLevelText = findViewById<TextView>(R.id.text_focus_level)
        val focusLevelIcon = findViewById<TextView>(R.id.icon_focus_level)
        val lightingQualityText = findViewById<TextView>(R.id.text_lighting_quality)
        val lightingQualityIcon = findViewById<TextView>(R.id.icon_lighting_quality)
        val engagementLevelText = findViewById<TextView>(R.id.text_engagement_level)
        val engagementLevelIcon = findViewById<TextView>(R.id.icon_engagement_level)
        val environmentStatusText = findViewById<TextView>(R.id.text_environment_status)
        val environmentStatusCard = findViewById<MaterialCardView>(R.id.card_environment_status)
        val startMonitoringButton = findViewById<Button>(R.id.button_start_monitoring)
        val stopMonitoringButton = findViewById<Button>(R.id.button_stop_monitoring)

        // Start monitoring on activity start
        viewModel.startMonitoring()

        // Setup button listeners
        startMonitoringButton.setOnClickListener {
            viewModel.startMonitoring()
        }

        stopMonitoringButton.setOnClickListener {
            viewModel.stopMonitoring()
        }

        // Observe sensor state
        lifecycleScope.launchWhenStarted {
            viewModel.sensorState.collect { state ->
                // Update quality score
                qualityScoreText.text = "${state.studyQualityScore}%"
                qualityScoreProgress.progress = state.studyQualityScore

                // Update focus level
                focusLevelText.text = state.focusLevel.replace("_", " ")
                focusLevelIcon.text = getFocusEmoji(state.focusLevel)
                focusLevelIcon.setTextColor(getFocusColor(state.focusLevel))

                // Update lighting quality
                lightingQualityText.text = state.lightingQuality.replace("_", " ")
                lightingQualityIcon.text = getLightingEmoji(state.lightingQuality)
                lightingQualityIcon.setTextColor(getLightingColor(state.lightingQuality))

                // Update engagement level
                engagementLevelText.text = state.engagementLevel.replace("_", " ")
                engagementLevelIcon.text = getEngagementEmoji(state.engagementLevel)
                engagementLevelIcon.setTextColor(getEngagementColor(state.engagementLevel))

                // Update environment status
                if (state.isOptimalEnvironment) {
                    environmentStatusText.text = "✓ Optimal Study Environment"
                    environmentStatusCard.setCardBackgroundColor(
                        resources.getColor(android.R.color.holo_green_light, null)
                    )
                } else {
                    environmentStatusText.text = "⚠ Not Optimal - Make Adjustments"
                    environmentStatusCard.setCardBackgroundColor(
                        resources.getColor(android.R.color.holo_orange_light, null)
                    )
                }
            }
        }

        lifecycleScope.launchWhenStarted {
            viewModel.isMonitoring.collect { isMonitoring ->
                startMonitoringButton.isEnabled = !isMonitoring
                stopMonitoringButton.isEnabled = isMonitoring
            }
        }
    }

    private fun getFocusEmoji(focusLevel: String): String {
        return when (focusLevel) {
            "HIGH_FOCUS" -> "🎯"
            "MEDIUM_FOCUS" -> "📌"
            else -> "📱"
        }
    }

    private fun getFocusColor(focusLevel: String): Int {
        return when (focusLevel) {
            "HIGH_FOCUS" -> resources.getColor(android.R.color.holo_green_dark, null)
            "MEDIUM_FOCUS" -> resources.getColor(android.R.color.holo_orange_dark, null)
            else -> resources.getColor(android.R.color.holo_red_dark, null)
        }
    }

    private fun getLightingEmoji(lighting: String): String {
        return when (lighting) {
            "OPTIMAL" -> "💡"
            "BRIGHT" -> "☀️"
            "TOO_BRIGHT" -> "🌞"
            "DIM" -> "🌙"
            "TOO_DARK" -> "🌑"
            else -> "❓"
        }
    }

    private fun getLightingColor(lighting: String): Int {
        return when (lighting) {
            "OPTIMAL" -> resources.getColor(android.R.color.holo_green_dark, null)
            "BRIGHT" -> resources.getColor(android.R.color.holo_blue_dark, null)
            "TOO_BRIGHT" -> resources.getColor(android.R.color.holo_orange_dark, null)
            "DIM" -> resources.getColor(android.R.color.holo_orange_dark, null)
            "TOO_DARK" -> resources.getColor(android.R.color.holo_red_dark, null)
            else -> resources.getColor(android.R.color.darker_gray, null)
        }
    }

    private fun getEngagementEmoji(engagement: String): String {
        return when (engagement) {
            "ACTIVELY_STUDYING" -> "✋"
            else -> "🎒"
        }
    }

    private fun getEngagementColor(engagement: String): Int {
        return when (engagement) {
            "ACTIVELY_STUDYING" -> resources.getColor(android.R.color.holo_green_dark, null)
            else -> resources.getColor(android.R.color.holo_red_dark, null)
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.startMonitoring()
    }

    override fun onPause() {
        super.onPause()
        viewModel.stopMonitoring()
    }
}
