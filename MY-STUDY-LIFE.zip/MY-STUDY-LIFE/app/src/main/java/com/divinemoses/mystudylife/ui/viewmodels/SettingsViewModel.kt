package com.divinemoses.mystudylife.ui.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.divinemoses.mystudylife.data.preferences.UserPreferences
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsState(
    val accelerometerSensitivity: Int = 5,
    val lightSensitivity: Int = 5,
    val proximitySensitivity: Int = 5,
    val autoSyncEnabled: Boolean = true,
    val syncFrequency: Int = 3600,
    val syncOnWifiOnly: Boolean = false,
    val notificationsEnabled: Boolean = true
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    application: Application
) : AndroidViewModel(application) {
    
    private val userPreferences = UserPreferences(application)
    
    private val _settingsState = MutableStateFlow(
        SettingsState(
            accelerometerSensitivity = userPreferences.accelerometerSensitivity,
            lightSensitivity = userPreferences.lightSensitivity,
            proximitySensitivity = userPreferences.proximitySensitivity,
            autoSyncEnabled = userPreferences.autoSyncEnabled,
            syncFrequency = userPreferences.syncFrequency,
            syncOnWifiOnly = userPreferences.syncOnWifiOnly,
            notificationsEnabled = userPreferences.notificationsEnabled
        )
    )
    val settingsState: StateFlow<SettingsState> = _settingsState.asStateFlow()

    fun updateAccelerometerSensitivity(value: Int) {
        userPreferences.accelerometerSensitivity = value
        _settingsState.value = _settingsState.value.copy(accelerometerSensitivity = value)
    }

    fun updateLightSensitivity(value: Int) {
        userPreferences.lightSensitivity = value
        _settingsState.value = _settingsState.value.copy(lightSensitivity = value)
    }

    fun updateProximitySensitivity(value: Int) {
        userPreferences.proximitySensitivity = value
        _settingsState.value = _settingsState.value.copy(proximitySensitivity = value)
    }

    fun updateAutoSyncEnabled(enabled: Boolean) {
        userPreferences.autoSyncEnabled = enabled
        _settingsState.value = _settingsState.value.copy(autoSyncEnabled = enabled)
    }

    fun updateSyncFrequency(frequency: Int) {
        userPreferences.syncFrequency = frequency
        _settingsState.value = _settingsState.value.copy(syncFrequency = frequency)
    }

    fun updateSyncOnWifiOnly(wifiOnly: Boolean) {
        userPreferences.syncOnWifiOnly = wifiOnly
        _settingsState.value = _settingsState.value.copy(syncOnWifiOnly = wifiOnly)
    }

    fun updateNotificationsEnabled(enabled: Boolean) {
        userPreferences.notificationsEnabled = enabled
        _settingsState.value = _settingsState.value.copy(notificationsEnabled = enabled)
    }

    fun resetToDefaults() {
        userPreferences.resetToDefaults()
        _settingsState.value = SettingsState()
    }
}
