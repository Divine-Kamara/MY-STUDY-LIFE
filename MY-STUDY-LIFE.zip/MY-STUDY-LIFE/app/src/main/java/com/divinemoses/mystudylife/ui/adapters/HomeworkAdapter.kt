package com.divinemoses.mystudylife.ui.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.divinemoses.mystudylife.data.models.HomeworkModel
import com.divinemoses.mystudylife.databinding.ItemHomeworkBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HomeworkAdapter(
    private val homework: List<HomeworkModel>,
    private val onHomeworkClick: (HomeworkModel) -> Unit,
    private val onDeleteClick: (HomeworkModel) -> Unit,
    private val onCompleteClick: (HomeworkModel) -> Unit
) : RecyclerView.Adapter<HomeworkAdapter.HomeworkViewHolder>() {

    inner class HomeworkViewHolder(private val binding: ItemHomeworkBinding) :
        RecyclerView.ViewHolder(binding.root) {
        
        fun bind(homeworkItem: HomeworkModel) {
            binding.apply {
                textTitle.text = homeworkItem.title
                textSubject.text = "Subject: ${homeworkItem.subject}"
                textDescription.text = homeworkItem.description
                
                val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
                textDueDate.text = "Due: ${dateFormat.format(Date(homeworkItem.dueDate))}"
                
                val priorityColor = when (homeworkItem.priority) {
                    "HIGH" -> android.graphics.Color.RED
                    "MEDIUM" -> android.graphics.Color.YELLOW
                    else -> android.graphics.Color.GREEN
                }
                cardHomework.setCardBackgroundColor(priorityColor)
                
                buttonCompleteMark.isChecked = homeworkItem.isCompleted
                buttonCompleteMark.setOnClickListener {
                    onCompleteClick(homeworkItem)
                }
                
                root.setOnClickListener {
                    onHomeworkClick(homeworkItem)
                }
                
                buttonDelete.setOnClickListener {
                    onDeleteClick(homeworkItem)
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HomeworkViewHolder {
        val binding = ItemHomeworkBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return HomeworkViewHolder(binding)
    }

    override fun onBindViewHolder(holder: HomeworkViewHolder, position: Int) {
        holder.bind(homework[position])
    }

    override fun getItemCount(): Int = homework.size
}
