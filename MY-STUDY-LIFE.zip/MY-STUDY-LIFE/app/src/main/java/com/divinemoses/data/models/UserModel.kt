package com.example.mystudylife.data.models

data class UserModel(
    val userId: String,
    val email: String,
    val displayName: String,
    val profilePictureUrl: String? = null,
    val institution: String = "",
    val studyLevel: String = "", // "HIGH_SCHOOL", "UNDERGRADUATE", "GRADUATE"
    val createdAt: Long = System.currentTimeMillis(),
    val cloudSyncEnabled: Boolean = true,
    val sensorDataEnabled: Boolean = true
)
