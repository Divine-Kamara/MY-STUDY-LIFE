package com.example.mystudylife.data.local

import androidx.room.*
import com.example.mystudylife.data.models.StudySessionModel
import kotlinx.coroutines.flow.Flow

@Dao
interface StudySessionDao {
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(sessionModel: StudySessionModel): Long
    
    @Query("SELECT * FROM study_sessions ORDER BY startTime DESC")
    fun getAllSessions(): Flow<List<StudySessionModel>>
    
    @Query("SELECT * FROM study_sessions WHERE classId = :classId ORDER BY startTime DESC")
    fun getSessionsByClass(classId: Int): Flow<List<StudySessionModel>>
    
    @Query("SELECT * FROM study_sessions WHERE startTime >= :startDate AND startTime <= :endDate ORDER BY startTime DESC")
    fun getSessionsByDateRange(startDate: Long, endDate: Long): Flow<List<StudySessionModel>>
    
    @Query("SELECT * FROM study_sessions WHERE id = :sessionId")
    suspend fun getSessionById(sessionId: Int): StudySessionModel?
    
    @Query("SELECT * FROM study_sessions WHERE cloudId = :cloudId")
    suspend fun getSessionByCloudId(cloudId: String): StudySessionModel?
    
    @Query("SELECT * FROM study_sessions WHERE syncedToCloud = 0")
    suspend fun getUnsyncedSessions(): List<StudySessionModel>
    
    @Update
    suspend fun updateSession(sessionModel: StudySessionModel)
    
    @Delete
    suspend fun deleteSession(sessionModel: StudySessionModel)
    
    @Query("SELECT AVG(studyQualityScore) FROM study_sessions WHERE classId = :classId")
    suspend fun getAverageQualityScore(classId: Int): Float
    
    @Query("SELECT COUNT(*) FROM study_sessions WHERE classId = :classId")
    suspend fun getTotalSessionCount(classId: Int): Int
}
