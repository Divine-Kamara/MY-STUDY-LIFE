package com.example.mystudylife.data.local

import androidx.room.*
import com.example.mystudylife.data.models.ExamModel
import kotlinx.coroutines.flow.Flow

@Dao
interface ExamDao {
    
    // INSERT
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExam(examModel: ExamModel): Long
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExams(exams: List<ExamModel>)
    
    // READ
    @Query("SELECT * FROM exams ORDER BY examDate ASC")
    fun getAllExams(): Flow<List<ExamModel>>
    
    @Query("SELECT * FROM exams WHERE id = :examId")
    suspend fun getExamById(examId: Int): ExamModel?
    
    @Query("SELECT * FROM exams WHERE cloudId = :cloudId")
    suspend fun getExamByCloudId(cloudId: String): ExamModel?
    
    @Query("SELECT * FROM exams WHERE classId = :classId ORDER BY examDate ASC")
    fun getExamsByClass(classId: Int): Flow<List<ExamModel>>
    
    @Query("SELECT * FROM exams WHERE examType = :examType ORDER BY examDate ASC")
    fun getExamsByType(examType: String): Flow<List<ExamModel>>
    
    @Query("SELECT * FROM exams WHERE examDate > :currentTime ORDER BY examDate ASC")
    fun getUpcomingExams(currentTime: Long): Flow<List<ExamModel>>
    
    @Query("SELECT * FROM exams WHERE examDate < :currentTime ORDER BY examDate DESC")
    fun getPastExams(currentTime: Long): Flow<List<ExamModel>>
    
    @Query("SELECT * FROM exams WHERE syncedToCloud = 0")
    suspend fun getUnsyncedExams(): List<ExamModel>
    
    // UPDATE
    @Update
    suspend fun updateExam(examModel: ExamModel)
    
    @Query("UPDATE exams SET actualScore = :score WHERE id = :examId")
    suspend fun updateExamScore(examId: Int, score: Int)
    
    @Query("UPDATE exams SET syncedToCloud = 1, cloudId = :cloudId WHERE id = :examId")
    suspend fun markExamAsSynced(examId: Int, cloudId: String)
    
    // DELETE
    @Delete
    suspend fun deleteExam(examModel: ExamModel)
    
    @Query("DELETE FROM exams WHERE id = :examId")
    suspend fun deleteExamById(examId: Int)
    
    @Query("DELETE FROM exams WHERE classId = :classId")
    suspend fun deleteExamsByClass(classId: Int)
    
    @Query("DELETE FROM exams")
    suspend fun deleteAllExams()
}
