package com.divinemoses.mystudylife.data.preferences

import android.content.Context
import android.content.SharedPreferences

class UserPreferences(context: Context) {
    private val sharedPreferences: SharedPreferences = context.getSharedPreferences(
        "com.divinemoses.mystudylife.prefs",
        Context.MODE_PRIVATE
    )

    companion object {
        private const val KEY_ACCELEROMETER_SENSITIVITY = "accelerometer_sensitivity"
        private const val KEY_LIGHT_SENSITIVITY = "light_sensitivity"
        private const val KEY_PROXIMITY_SENSITIVITY = "proximity_sensitivity"
        private const val KEY_AUTO_SYNC_ENABLED = "auto_sync_enabled"
        private const val KEY_SYNC_FREQUENCY = "sync_frequency"
        private const val KEY_SYNC_ON_WIFI_ONLY = "sync_on_wifi_only"
        private const val KEY_NOTIFICATIONS_ENABLED = "notifications_enabled"

        private const val DEFAULT_ACCELEROMETER_SENSITIVITY = 5
        private const val DEFAULT_LIGHT_SENSITIVITY = 5
        private const val DEFAULT_PROXIMITY_SENSITIVITY = 5
        private const val DEFAULT_AUTO_SYNC_ENABLED = true
        private const val DEFAULT_SYNC_FREQUENCY = 3600 // 1 hour
        private const val DEFAULT_SYNC_ON_WIFI_ONLY = false
        private const val DEFAULT_NOTIFICATIONS_ENABLED = true
    }

    // Accelerometer Sensitivity (1-10)
    var accelerometerSensitivity: Int
        get() = sharedPreferences.getInt(KEY_ACCELEROMETER_SENSITIVITY, DEFAULT_ACCELEROMETER_SENSITIVITY)
        set(value) = sharedPreferences.edit().putInt(KEY_ACCELEROMETER_SENSITIVITY, value).apply()

    // Light Sensor Sensitivity (1-10)
    var lightSensitivity: Int
        get() = sharedPreferences.getInt(KEY_LIGHT_SENSITIVITY, DEFAULT_LIGHT_SENSITIVITY)
        set(value) = sharedPreferences.edit().putInt(KEY_LIGHT_SENSITIVITY, value).apply()

    // Proximity Sensor Sensitivity (1-10)
    var proximitySensitivity: Int
        get() = sharedPreferences.getInt(KEY_PROXIMITY_SENSITIVITY, DEFAULT_PROXIMITY_SENSITIVITY)
        set(value) = sharedPreferences.edit().putInt(KEY_PROXIMITY_SENSITIVITY, value).apply()

    // Auto Sync Enabled
    var autoSyncEnabled: Boolean
        get() = sharedPreferences.getBoolean(KEY_AUTO_SYNC_ENABLED, DEFAULT_AUTO_SYNC_ENABLED)
        set(value) = sharedPreferences.edit().putBoolean(KEY_AUTO_SYNC_ENABLED, value).apply()

    // Sync Frequency (in seconds)
    var syncFrequency: Int
        get() = sharedPreferences.getInt(KEY_SYNC_FREQUENCY, DEFAULT_SYNC_FREQUENCY)
        set(value) = sharedPreferences.edit().putInt(KEY_SYNC_FREQUENCY, value).apply()

    // Sync on WiFi Only
    var syncOnWifiOnly: Boolean
        get() = sharedPreferences.getBoolean(KEY_SYNC_ON_WIFI_ONLY, DEFAULT_SYNC_ON_WIFI_ONLY)
        set(value) = sharedPreferences.edit().putBoolean(KEY_SYNC_ON_WIFI_ONLY, value).apply()

    // Notifications Enabled
    var notificationsEnabled: Boolean
        get() = sharedPreferences.getBoolean(KEY_NOTIFICATIONS_ENABLED, DEFAULT_NOTIFICATIONS_ENABLED)
        set(value) = sharedPreferences.edit().putBoolean(KEY_NOTIFICATIONS_ENABLED, value).apply()

    // Reset to defaults
    fun resetToDefaults() {
        accelerometerSensitivity = DEFAULT_ACCELEROMETER_SENSITIVITY
        lightSensitivity = DEFAULT_LIGHT_SENSITIVITY
        proximitySensitivity = DEFAULT_PROXIMITY_SENSITIVITY
        autoSyncEnabled = DEFAULT_AUTO_SYNC_ENABLED
        syncFrequency = DEFAULT_SYNC_FREQUENCY
        syncOnWifiOnly = DEFAULT_SYNC_ON_WIFI_ONLY
        notificationsEnabled = DEFAULT_NOTIFICATIONS_ENABLED
    }
}
