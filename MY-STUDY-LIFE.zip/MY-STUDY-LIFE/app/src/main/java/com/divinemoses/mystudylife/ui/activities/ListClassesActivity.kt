package com.divinemoses.mystudylife.ui.activities

import android.os.Bundle
import android.widget.Button
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.divinemoses.mystudylife.R
import com.divinemoses.mystudylife.ui.adapters.ClassAdapter
import com.divinemoses.mystudylife.ui.viewmodels.ClassViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class ListClassesActivity : AppCompatActivity() {
    private val classViewModel: ClassViewModel by viewModels()
    private lateinit var recyclerView: RecyclerView
    private lateinit var backButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_classes)

        recyclerView = findViewById(R.id.recycler_classes)
        backButton = findViewById(R.id.button_back)

        recyclerView.layoutManager = LinearLayoutManager(this)

        backButton.setOnClickListener {
            finish()
        }

        lifecycleScope.launch {
            classViewModel.classes.collect { classes ->
                val adapter = ClassAdapter(
                    classes = classes,
                    onClassClick = { classItem ->
                        // Handle class click - could show detail or edit screen
                    },
                    onDeleteClick = { classItem ->
                        classViewModel.deleteClass(classItem)
                    }
                )
                recyclerView.adapter = adapter
            }
        }
    }
}
