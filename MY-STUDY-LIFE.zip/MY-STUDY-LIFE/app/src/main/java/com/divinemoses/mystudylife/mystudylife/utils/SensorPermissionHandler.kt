package com.example.mystudylife.utils

import android.content.Context
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.appcompat.app.AppCompatActivity

/**
 * Manages sensor permission requests using Activity Result API
 * Handles permission state and user interactions
 */
class SensorPermissionHandler(private val context: Context) {
    
    var onPermissionsGranted: (() -> Unit)? = null
    var onPermissionsDenied: (() -> Unit)? = null
    
    private var permissionLauncher: ActivityResultLauncher<Array<String>>? = null
    
    fun setupPermissionLauncher(activity: AppCompatActivity) {
        permissionLauncher = activity.registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { permissions ->
            handlePermissionResult(permissions)
        }
    }
    
    fun setupPermissionLauncher(fragment: Fragment) {
        permissionLauncher = fragment.registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { permissions ->
            handlePermissionResult(permissions)
        }
    }
    
    fun requestSensorPermissions() {
        if (PermissionUtils.areSensorPermissionsGranted(context)) {
            onPermissionsGranted?.invoke()
            return
        }
        
        val permissions = PermissionUtils.getRequiredSensorPermissions()
        permissionLauncher?.launch(permissions)
    }
    
    private fun handlePermissionResult(permissions: Map<String, Boolean>) {
        val allGranted = permissions.all { it.value }
        
        if (allGranted) {
            onPermissionsGranted?.invoke()
        } else {
            val deniedPermissions = permissions.filter { !it.value }.keys.toList()
            handleDeniedPermissions(deniedPermissions)
        }
    }
    
    private fun handleDeniedPermissions(deniedPermissions: List<String>) {
        onPermissionsDenied?.invoke()
        
        // Show user-friendly message about what permission was denied
        val message = buildDeniedPermissionMessage(deniedPermissions)
        showPermissionDialog(message, deniedPermissions)
    }
    
    private fun buildDeniedPermissionMessage(deniedPermissions: List<String>): String {
        val reasons = mutableListOf<String>()
        
        deniedPermissions.forEach { permission ->
            when (permission) {
                PermissionUtils.BODY_SENSORS -> reasons.add("Sensor access")
                PermissionUtils.BODY_SENSORS_BACKGROUND -> reasons.add("Background sensor access")
            }
        }
        
        return "The following permissions are needed for sensor monitoring:\n" +
               reasons.joinToString("\n") { "• $it" } +
               "\n\nWithout these permissions, sensor tracking features will be disabled."
    }
    
    private fun showPermissionDialog(message: String, deniedPermissions: List<String>) {
        AlertDialog.Builder(context)
            .setTitle("Sensor Permissions Required")
            .setMessage(message)
            .setPositiveButton("Retry") { _, _ ->
                permissionLauncher?.launch(deniedPermissions.toTypedArray())
            }
            .setNegativeButton("Continue Without") { _, _ ->
                // User chose to continue without permissions
            }
            .setCancelable(false)
            .show()
    }
    
    fun areSensorsAvailable(): Map<String, Boolean> {
        return mapOf(
            "accelerometer" to PermissionUtils.hasAccelerometer(context),
            "light_sensor" to PermissionUtils.hasLightSensor(context),
            "proximity_sensor" to PermissionUtils.hasProximitySensor(context)
        )
    }
}
