package com.example.mystudylife.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mystudylife.data.models.ExamModel
import com.example.mystudylife.domain.repositories.ExamRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ExamViewModel @Inject constructor(
    private val examRepository: ExamRepository
) : ViewModel() {
    val exams: StateFlow<List<ExamModel>> = examRepository
        .getAllExams()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun insertExam(examModel: ExamModel) {
        viewModelScope.launch {
            examRepository.insertExam(examModel)
        }
    }

    fun updateScore(examId: Int, score: Int) {
        viewModelScope.launch {
            examRepository.updateExamScore(examId, score)
        }
    }
}
