package com.example.mystudylife.domain.repositories

import com.example.mystudylife.data.models.StudySessionModel
import kotlinx.coroutines.flow.Flow

interface StudySessionRepository {
    suspend fun insertSession(sessionModel: StudySessionModel): Long
    fun getAllSessions(): Flow<List<StudySessionModel>>
    fun getSessionsByClass(classId: Int): Flow<List<StudySessionModel>>
    fun getSessionsByDateRange(startDate: Long, endDate: Long): Flow<List<StudySessionModel>>
    suspend fun getSessionById(sessionId: Int): StudySessionModel?
    suspend fun updateSession(sessionModel: StudySessionModel)
    suspend fun deleteSession(sessionModel: StudySessionModel)
    suspend fun getAverageQualityScore(classId: Int): Float
    suspend fun getTotalSessionCount(classId: Int): Int
}
