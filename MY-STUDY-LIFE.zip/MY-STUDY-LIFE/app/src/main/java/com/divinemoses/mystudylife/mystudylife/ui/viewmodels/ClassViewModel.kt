package com.example.mystudylife.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mystudylife.data.models.ClassModel
import com.example.mystudylife.domain.repositories.ClassRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ClassViewModel @Inject constructor(
    private val classRepository: ClassRepository
) : ViewModel() {
    val classes: StateFlow<List<ClassModel>> = classRepository
        .getAllClasses()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun insertClass(classModel: ClassModel) {
        viewModelScope.launch {
            classRepository.insertClass(classModel)
        }
    }

    fun deleteClass(classModel: ClassModel) {
        viewModelScope.launch {
            classRepository.deleteClass(classModel)
        }
    }
}
