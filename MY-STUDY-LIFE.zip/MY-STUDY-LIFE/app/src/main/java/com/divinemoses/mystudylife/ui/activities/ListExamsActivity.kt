package com.divinemoses.mystudylife.ui.activities

import android.os.Bundle
import android.widget.Button
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.divinemoses.mystudylife.R
import com.divinemoses.mystudylife.ui.adapters.ExamAdapter
import com.divinemoses.mystudylife.ui.viewmodels.ExamViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class ListExamsActivity : AppCompatActivity() {
    private val examViewModel: ExamViewModel by viewModels()
    private lateinit var recyclerView: RecyclerView
    private lateinit var backButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_exams)

        recyclerView = findViewById(R.id.recycler_exams)
        backButton = findViewById(R.id.button_back)

        recyclerView.layoutManager = LinearLayoutManager(this)

        backButton.setOnClickListener {
            finish()
        }

        lifecycleScope.launch {
            examViewModel.exams.collect { exams ->
                val adapter = ExamAdapter(
                    exams = exams,
                    onExamClick = { exam ->
                        // Handle exam click - could show detail or edit screen
                    },
                    onDeleteClick = { exam ->
                        examViewModel.deleteExam(exam)
                    }
                )
                recyclerView.adapter = adapter
            }
        }
    }
}
