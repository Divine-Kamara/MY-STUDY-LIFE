package com.example.mystudylife.ui.activities

import android.os.Bundle
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.mystudylife.R
import com.example.mystudylife.data.models.HomeworkModel
import com.example.mystudylife.ui.viewmodels.HomeworkViewModel
import com.google.android.material.textfield.TextInputEditText
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class AddHomeworkActivity : AppCompatActivity() {
    private val homeworkViewModel: HomeworkViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_homework)

        val titleInput = findViewById<TextInputEditText>(R.id.input_homework_title)
        val classNameInput = findViewById<TextInputEditText>(R.id.input_homework_class)
        val descriptionInput = findViewById<TextInputEditText>(R.id.input_homework_description)
        val dueDateInput = findViewById<TextInputEditText>(R.id.input_homework_due_date)
        val prioritySpinner = findViewById<Spinner>(R.id.spinner_priority)
        val saveButton = findViewById<Button>(R.id.button_save_homework)

        // Setup priority spinner
        val priorityOptions = arrayOf("Select priority...", "LOW", "MEDIUM", "HIGH")
        setupSpinner(prioritySpinner, priorityOptions)

        saveButton.setOnClickListener {
            if (titleInput.text.toString().isEmpty()) {
                Toast.makeText(this, "Please enter assignment title", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val homeworkModel = HomeworkModel(
                title = titleInput.text.toString().trim(),
                classId = 0,
                className = classNameInput.text.toString().trim(),
                description = descriptionInput.text.toString().trim(),
                dueDate = parseDateToTimestamp(dueDateInput.text.toString()),
                priority = prioritySpinner.selectedItem.toString().takeIf { it != "Select priority..." } ?: "MEDIUM"
            )
            homeworkViewModel.insertHomework(homeworkModel)
            Toast.makeText(this, getString(R.string.msg_homework_saved), Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun setupSpinner(spinner: Spinner, options: Array<String>) {
        val adapter = android.widget.ArrayAdapter(this, android.R.layout.simple_spinner_item, options)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
    }

    private fun parseDateToTimestamp(dateString: String): Long {
        return try {
            val parts = dateString.split("-")
            if (parts.size == 3) {
                val year = parts[0].toInt()
                val month = parts[1].toInt() - 1
                val day = parts[2].toInt()
                java.util.Calendar.getInstance().apply {
                    set(year, month, day, 0, 0, 0)
                    set(java.util.Calendar.MILLISECOND, 0)
                }.timeInMillis
            } else {
                System.currentTimeMillis()
            }
        } catch (e: Exception) {
            System.currentTimeMillis()
        }
    }
}
