package com.example.mystudylife.domain.repositories

import com.example.mystudylife.data.models.HomeworkModel
import kotlinx.coroutines.flow.Flow

interface HomeworkRepository {
    suspend fun insertHomework(homeworkModel: HomeworkModel): Long
    suspend fun insertHomeworkList(homework: List<HomeworkModel>)
    fun getAllHomework(): Flow<List<HomeworkModel>>
    suspend fun getHomeworkById(homeworkId: Int): HomeworkModel?
    fun getHomeworkByClass(classId: Int): Flow<List<HomeworkModel>>
    fun getPendingHomework(): Flow<List<HomeworkModel>>
    fun getCompletedHomework(): Flow<List<HomeworkModel>>
    fun getHomeworkByPriority(priority: String): Flow<List<HomeworkModel>>
    suspend fun getUnsyncedHomework(): List<HomeworkModel>
    suspend fun updateHomework(homeworkModel: HomeworkModel)
    suspend fun markHomeworkAsComplete(homeworkId: Int, completedDate: Long)
    suspend fun markHomeworkAsSynced(homeworkId: Int, cloudId: String)
    suspend fun deleteHomework(homeworkModel: HomeworkModel)
    suspend fun deleteHomeworkById(homeworkId: Int)
    suspend fun deleteHomeworkByClass(classId: Int)
    suspend fun deleteAllHomework()
}
