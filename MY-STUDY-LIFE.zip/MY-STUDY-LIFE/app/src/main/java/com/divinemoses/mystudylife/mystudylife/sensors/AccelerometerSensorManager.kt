package com.example.mystudylife.sensors

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.sqrt

/**
 * Accelerometer Sensor Manager
 * 
 * Purpose: Detects device movement and physical activity
 * Use Cases: 
 * - Detect if student is actively studying (low movement = focused)
 * - Alert if student is being too inactive (health reminder)
 * - Track study session intensity
 * 
 * Data collected: X, Y, Z axis acceleration values
 */
class AccelerometerSensorManager(private val context: Context) : SensorEventListener {
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    
    private var movementIntensity = 0f
    private var isDeviceShaking = false
    private val shakeThreshold = 20f // m/s²
    private val noMovementThreshold = 1.5f // m/s²
    
    var onMovementDetected: ((intensity: Float) -> Unit)? = null
    var onShakeDetected: (() -> Unit)? = null
    
    fun startListening() {
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }
    
    fun stopListening() {
        sensorManager.unregisterListener(this)
    }
    
    override fun onSensorChanged(event: SensorEvent?) {
        event?.let {
            if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
                val x = event.values[0]
                val y = event.values[1]
                val z = event.values[2]
                
                // Calculate magnitude of acceleration (excluding gravity ~9.8 m/s²)
                val magnitude = sqrt(x * x + y * y + z * z) - 9.8f
                movementIntensity = magnitude
                
                // Detect shaking (sudden high movement)
                if (magnitude > shakeThreshold) {
                    if (!isDeviceShaking) {
                        isDeviceShaking = true
                        onShakeDetected?.invoke()
                    }
                } else {
                    isDeviceShaking = false
                }
                
                // Notify movement detected
                onMovementDetected?.invoke(magnitude)
            }
        }
    }
    
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    
    fun getStudyFocusLevel(): String {
        return when {
            movementIntensity < noMovementThreshold -> "HIGH_FOCUS" // Very still = focused
            movementIntensity < 5f -> "MEDIUM_FOCUS"
            else -> "LOW_FOCUS" // Too much movement
        }
    }
}
