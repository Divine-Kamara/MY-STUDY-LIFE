package com.example.mystudylife.ui.activities

import android.os.Bundle
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.mystudylife.R
import com.example.mystudylife.data.models.ExamModel
import com.example.mystudylife.ui.viewmodels.ExamViewModel
import com.google.android.material.textfield.TextInputEditText
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class AddExamActivity : AppCompatActivity() {
    private val examViewModel: ExamViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_exam)

        val titleInput = findViewById<TextInputEditText>(R.id.input_exam_title)
        val classNameInput = findViewById<TextInputEditText>(R.id.input_exam_class)
        val descriptionInput = findViewById<TextInputEditText>(R.id.input_exam_description)
        val examDateInput = findViewById<TextInputEditText>(R.id.input_exam_date)
        val startTimeInput = findViewById<TextInputEditText>(R.id.input_exam_start_time)
        val endTimeInput = findViewById<TextInputEditText>(R.id.input_exam_end_time)
        val locationInput = findViewById<TextInputEditText>(R.id.input_exam_location)
        val examTypeSpinner = findViewById<Spinner>(R.id.spinner_exam_type)
        val saveButton = findViewById<Button>(R.id.button_save_exam)

        // Setup exam type spinner
        val examTypes = arrayOf("Select type...", "MIDTERM", "FINAL", "QUIZ", "PRACTICE", "OTHER")
        setupSpinner(examTypeSpinner, examTypes)

        saveButton.setOnClickListener {
            if (titleInput.text.toString().isEmpty()) {
                Toast.makeText(this, "Please enter exam title", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val examModel = ExamModel(
                title = titleInput.text.toString().trim(),
                classId = 0,
                className = classNameInput.text.toString().trim(),
                description = descriptionInput.text.toString().trim(),
                examDate = parseDateToTimestamp(examDateInput.text.toString()),
                startTime = startTimeInput.text.toString().trim(),
                endTime = endTimeInput.text.toString().trim(),
                location = locationInput.text.toString().trim(),
                examType = examTypeSpinner.selectedItem.toString().takeIf { it != "Select type..." } ?: "OTHER"
            )
            examViewModel.insertExam(examModel)
            Toast.makeText(this, getString(R.string.msg_exam_saved), Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun setupSpinner(spinner: Spinner, options: Array<String>) {
        val adapter = android.widget.ArrayAdapter(this, android.R.layout.simple_spinner_item, options)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
    }

    private fun parseDateToTimestamp(dateString: String): Long {
        return try {
            val parts = dateString.split("-")
            if (parts.size == 3) {
                val year = parts[0].toInt()
                val month = parts[1].toInt() - 1
                val day = parts[2].toInt()
                java.util.Calendar.getInstance().apply {
                    set(year, month, day, 0, 0, 0)
                    set(java.util.Calendar.MILLISECOND, 0)
                }.timeInMillis
            } else {
                System.currentTimeMillis()
            }
        } catch (e: Exception) {
            System.currentTimeMillis()
        }
    }
}
