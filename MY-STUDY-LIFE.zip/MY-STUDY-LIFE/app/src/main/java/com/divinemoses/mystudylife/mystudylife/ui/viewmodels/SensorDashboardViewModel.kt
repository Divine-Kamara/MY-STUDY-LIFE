package com.example.mystudylife.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mystudylife.sensors.SensorDataManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject

@HiltViewModel
class SensorDashboardViewModel @Inject constructor(
    private val sensorDataManager: SensorDataManager
) : ViewModel() {
    
    data class SensorUIState(
        val focusLevel: String = "N/A",
        val lightingQuality: String = "N/A",
        val engagementLevel: String = "N/A",
        val studyQualityScore: Int = 0,
        val isOptimalEnvironment: Boolean = false,
        val timestamp: Long = System.currentTimeMillis()
    )
    
    private val _sensorState = MutableStateFlow(SensorUIState())
    val sensorState: StateFlow<SensorUIState> = _sensorState.asStateFlow()
    
    private val _isMonitoring = MutableStateFlow(false)
    val isMonitoring: StateFlow<Boolean> = _isMonitoring.asStateFlow()
    
    private val _focusHistory = MutableStateFlow<List<String>>(emptyList())
    val focusHistory: StateFlow<List<String>> = _focusHistory.asStateFlow()
    
    init {
        setupSensorCallbacks()
    }
    
    private fun setupSensorCallbacks() {
        sensorDataManager.onMetricsUpdated = { metrics ->
            _sensorState.value = SensorUIState(
                focusLevel = metrics.focusLevel,
                lightingQuality = metrics.lightingQuality,
                engagementLevel = metrics.engagementLevel,
                studyQualityScore = sensorDataManager.getStudyQualityScore(),
                isOptimalEnvironment = sensorDataManager.isOptimalStudyEnvironment(),
                timestamp = metrics.timestamp
            )
            
            // Update focus history
            updateFocusHistory(metrics.focusLevel)
        }
    }
    
    private fun updateFocusHistory(focusLevel: String) {
        val history = _focusHistory.value.toMutableList()
        if (history.size >= 20) {
            history.removeAt(0) // Keep last 20 readings
        }
        history.add(focusLevel)
        _focusHistory.value = history
    }
    
    fun startMonitoring() {
        sensorDataManager.startMonitoring()
        _isMonitoring.value = true
    }
    
    fun stopMonitoring() {
        sensorDataManager.stopMonitoring()
        _isMonitoring.value = false
    }
    
    fun getCurrentScore(): Int {
        return sensorDataManager.getStudyQualityScore()
    }
}
