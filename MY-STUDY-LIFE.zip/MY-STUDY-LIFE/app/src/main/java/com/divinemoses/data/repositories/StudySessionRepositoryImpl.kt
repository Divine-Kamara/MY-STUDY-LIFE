package com.example.mystudylife.data.repositories

import com.example.mystudylife.data.local.StudySessionDao
import com.example.mystudylife.data.models.StudySessionModel
import com.example.mystudylife.domain.repositories.StudySessionRepository
import kotlinx.coroutines.flow.Flow

class StudySessionRepositoryImpl(
    private val studySessionDao: StudySessionDao
) : StudySessionRepository {
    override suspend fun insertSession(sessionModel: StudySessionModel): Long {
        return studySessionDao.insertSession(sessionModel)
    }

    override fun getAllSessions(): Flow<List<StudySessionModel>> {
        return studySessionDao.getAllSessions()
    }

    override fun getSessionsByClass(classId: Int): Flow<List<StudySessionModel>> {
        return studySessionDao.getSessionsByClass(classId)
    }

    override fun getSessionsByDateRange(startDate: Long, endDate: Long): Flow<List<StudySessionModel>> {
        return studySessionDao.getSessionsByDateRange(startDate, endDate)
    }

    override suspend fun getSessionById(sessionId: Int): StudySessionModel? {
        return studySessionDao.getSessionById(sessionId)
    }

    override suspend fun updateSession(sessionModel: StudySessionModel) {
        studySessionDao.updateSession(sessionModel)
    }

    override suspend fun deleteSession(sessionModel: StudySessionModel) {
        studySessionDao.deleteSession(sessionModel)
    }

    override suspend fun getAverageQualityScore(classId: Int): Float {
        return studySessionDao.getAverageQualityScore(classId) ?: 0f
    }

    override suspend fun getTotalSessionCount(classId: Int): Int {
        return studySessionDao.getTotalSessionCount(classId)
    }
}
