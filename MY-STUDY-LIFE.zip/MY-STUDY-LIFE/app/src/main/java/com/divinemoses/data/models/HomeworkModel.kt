package com.example.mystudylife.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

@Entity(tableName = "homework")
data class HomeworkModel(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,
    val classId: Int,
    val className: String,
    val description: String,
    val dueDate: Long, // Timestamp
    val priority: String, // "LOW", "MEDIUM", "HIGH"
    val isCompleted: Boolean = false,
    val completedDate: Long? = null,
    val attachment: String? = null, // File path or URL
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val syncedToCloud: Boolean = false,
    val cloudId: String = ""
)
