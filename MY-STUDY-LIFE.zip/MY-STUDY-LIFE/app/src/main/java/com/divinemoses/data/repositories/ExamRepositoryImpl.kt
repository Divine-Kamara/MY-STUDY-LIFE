package com.example.mystudylife.data.repositories

import com.example.mystudylife.data.local.ExamDao
import com.example.mystudylife.data.models.ExamModel
import com.example.mystudylife.domain.repositories.ExamRepository
import kotlinx.coroutines.flow.Flow

class ExamRepositoryImpl(
    private val examDao: ExamDao
) : ExamRepository {
    override suspend fun insertExam(examModel: ExamModel): Long {
        return examDao.insertExam(examModel)
    }

    override suspend fun insertExams(exams: List<ExamModel>) {
        examDao.insertExams(exams)
    }

    override fun getAllExams(): Flow<List<ExamModel>> {
        return examDao.getAllExams()
    }

    override suspend fun getExamById(examId: Int): ExamModel? {
        return examDao.getExamById(examId)
    }

    override fun getExamsByClass(classId: Int): Flow<List<ExamModel>> {
        return examDao.getExamsByClass(classId)
    }

    override fun getExamsByType(examType: String): Flow<List<ExamModel>> {
        return examDao.getExamsByType(examType)
    }

    override fun getUpcomingExams(currentTime: Long): Flow<List<ExamModel>> {
        return examDao.getUpcomingExams(currentTime)
    }

    override fun getPastExams(currentTime: Long): Flow<List<ExamModel>> {
        return examDao.getPastExams(currentTime)
    }

    override suspend fun getUnsyncedExams(): List<ExamModel> {
        return examDao.getUnsyncedExams()
    }

    override suspend fun updateExam(examModel: ExamModel) {
        examDao.updateExam(examModel)
    }

    override suspend fun updateExamScore(examId: Int, score: Int) {
        examDao.updateExamScore(examId, score)
    }

    override suspend fun markExamAsSynced(examId: Int, cloudId: String) {
        examDao.markExamAsSynced(examId, cloudId)
    }

    override suspend fun deleteExam(examModel: ExamModel) {
        examDao.deleteExam(examModel)
    }

    override suspend fun deleteExamById(examId: Int) {
        examDao.deleteExamById(examId)
    }

    override suspend fun deleteExamsByClass(classId: Int) {
        examDao.deleteExamsByClass(classId)
    }

    override suspend fun deleteAllExams() {
        examDao.deleteAllExams()
    }
}
