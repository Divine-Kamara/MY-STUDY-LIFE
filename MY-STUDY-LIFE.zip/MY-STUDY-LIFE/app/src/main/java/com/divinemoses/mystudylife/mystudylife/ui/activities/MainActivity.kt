package com.example.mystudylife.ui.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.mystudylife.R
import com.example.mystudylife.services.CloudSyncService
import com.example.mystudylife.ui.activities.AddClassActivity
import com.example.mystudylife.ui.activities.AddExamActivity
import com.example.mystudylife.ui.activities.AddHomeworkActivity
import com.example.mystudylife.ui.activities.SensorDashboardActivity
import com.example.mystudylife.ui.viewmodels.ClassViewModel
import com.example.mystudylife.ui.viewmodels.ExamViewModel
import com.example.mystudylife.ui.viewmodels.HomeworkViewModel
import com.example.mystudylife.utils.PermissionUtils
import com.example.mystudylife.utils.SensorPermissionHandler
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {
    private val classViewModel: ClassViewModel by viewModels()
    private val homeworkViewModel: HomeworkViewModel by viewModels()
    private val examViewModel: ExamViewModel by viewModels()
    
    @Inject
    lateinit var sensorDataManager: SensorDataManager
    
    private lateinit var permissionHandler: SensorPermissionHandler

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        // Initialize permission handler
        permissionHandler = SensorPermissionHandler(this)
        permissionHandler.setupPermissionLauncher(this)
        
        // Setup permission callbacks
        permissionHandler.onPermissionsGranted = {
            initializeSensorMonitoring()
            showSensorStatus()
        }
        
        permissionHandler.onPermissionsDenied = {
            Toast.makeText(this, "Sensor permissions denied. Some features will be limited.", Toast.LENGTH_LONG).show()
        }
        
        // Check available sensors
        checkAvailableSensors()

        val classesCount = findViewById<TextView>(R.id.text_classes_count)
        val homeworkCount = findViewById<TextView>(R.id.text_homework_count)
        val examsCount = findViewById<TextView>(R.id.text_exams_count)
        val addClassButton = findViewById<Button>(R.id.button_add_class)
        val addHomeworkButton = findViewById<Button>(R.id.button_add_homework)
        val addExamButton = findViewById<Button>(R.id.button_add_exam)
        val sensorDashboardButton = findViewById<Button>(R.id.button_sensor_dashboard)
        val syncCloudButton = findViewById<Button>(R.id.button_sync_cloud)

        addClassButton.setOnClickListener {
            startActivity(Intent(this, AddClassActivity::class.java))
        }

        addHomeworkButton.setOnClickListener {
            startActivity(Intent(this, AddHomeworkActivity::class.java))
        }

        addExamButton.setOnClickListener {
            startActivity(Intent(this, AddExamActivity::class.java))
        }

        sensorDashboardButton.setOnClickListener {
            startActivity(Intent(this, SensorDashboardActivity::class.java))
        }

        syncCloudButton.setOnClickListener {
            startCloudSync()
        }

        lifecycleScope.launchWhenStarted {
            classViewModel.classes.collect { classes ->
                classesCount.text = getString(R.string.label_classes_count, classes.size)
            }
        }

        lifecycleScope.launchWhenStarted {
            homeworkViewModel.homeworkList.collect { homework ->
                homeworkCount.text = getString(R.string.label_homework_count, homework.size)
            }
        }

        lifecycleScope.launchWhenStarted {
            examViewModel.exams.collect { exams ->
                examsCount.text = getString(R.string.label_exams_count, exams.size)
            }
        }
        
        // Request sensor permissions on startup
        if (PermissionUtils.areSensorPermissionsGranted(this)) {
            initializeSensorMonitoring()
            showSensorStatus()
        } else {
            permissionHandler.requestSensorPermissions()
        }
    }

    private fun startCloudSync() {
        val syncIntent = Intent(this, CloudSyncService::class.java).apply {
            action = CloudSyncService.ACTION_SYNC_ALL
        }
        startService(syncIntent)
        Toast.makeText(this, "Syncing data to cloud...", Toast.LENGTH_SHORT).show()
    }
    
    private fun initializeSensorMonitoring() {
        sensorDataManager.startMonitoring()
        
        // Listen for sensor data updates
        sensorDataManager.onMetricsUpdated = { metrics ->
            // Log sensor metrics (for debugging)
            android.util.Log.d("Sensors", "Focus: ${metrics.focusLevel}, Lighting: ${metrics.lightingQuality}, Engagement: ${metrics.engagementLevel}")
        }
    }
    
    private fun checkAvailableSensors() {
        val availableSensors = permissionHandler.areSensorsAvailable()
        val sb = StringBuilder("Available sensors:\n")
        availableSensors.forEach { (sensor, isAvailable) ->
            sb.append("$sensor: ${if (isAvailable) "✓" else "✗"}\n")
        }
        android.util.Log.d("Sensors", sb.toString())
    }
    
    private fun showSensorStatus() {
        val sensors = permissionHandler.areSensorsAvailable()
        val available = sensors.count { it.value }
        val total = sensors.size
        Toast.makeText(this, "Sensors active: $available/$total", Toast.LENGTH_SHORT).show()
    }
    
    override fun onResume() {
        super.onResume()
        if (::sensorDataManager.isInitialized) {
            sensorDataManager.startMonitoring()
        }
    }
    
    override fun onPause() {
        super.onPause()
        if (::sensorDataManager.isInitialized) {
            sensorDataManager.stopMonitoring()
        }
    }
}
