package com.example.mystudylife.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mystudylife.data.models.HomeworkModel
import com.example.mystudylife.domain.repositories.HomeworkRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeworkViewModel @Inject constructor(
    private val homeworkRepository: HomeworkRepository
) : ViewModel() {
    val homeworkList: StateFlow<List<HomeworkModel>> = homeworkRepository
        .getAllHomework()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun insertHomework(homeworkModel: HomeworkModel) {
        viewModelScope.launch {
            homeworkRepository.insertHomework(homeworkModel)
        }
    }

    fun markAsComplete(homeworkId: Int, completedDate: Long) {
        viewModelScope.launch {
            homeworkRepository.markHomeworkAsComplete(homeworkId, completedDate)
        }
    }
}
