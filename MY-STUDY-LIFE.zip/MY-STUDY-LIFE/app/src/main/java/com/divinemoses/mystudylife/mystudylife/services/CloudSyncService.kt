package com.example.mystudylife.services

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log
import com.example.mystudylife.data.local.AppDatabase
import com.example.mystudylife.data.models.ClassModel
import com.example.mystudylife.data.models.ExamModel
import com.example.mystudylife.data.models.HomeworkModel
import com.example.mystudylife.data.models.StudySessionModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

@AndroidEntryPoint
class CloudSyncService : Service() {

    @Inject
    lateinit var database: AppDatabase

    private val firestore = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val serviceScope = CoroutineScope(Dispatchers.IO)

    companion object {
        private const val TAG = "CloudSyncService"
        const val ACTION_SYNC_ALL = "com.example.mystudylife.SYNC_ALL"
        const val ACTION_SYNC_CLASSES = "com.example.mystudylife.SYNC_CLASSES"
        const val ACTION_SYNC_HOMEWORK = "com.example.mystudylife.SYNC_HOMEWORK"
        const val ACTION_SYNC_EXAMS = "com.example.mystudylife.SYNC_EXAMS"
        const val ACTION_SYNC_SESSIONS = "com.example.mystudylife.SYNC_SESSIONS"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SYNC_ALL -> syncAllData()
            ACTION_SYNC_CLASSES -> syncClasses()
            ACTION_SYNC_HOMEWORK -> syncHomework()
            ACTION_SYNC_EXAMS -> syncExams()
            ACTION_SYNC_SESSIONS -> syncStudySessions()
            else -> syncAllData()
        }
        return START_NOT_STICKY
    }

    private fun syncAllData() {
        serviceScope.launch {
            try {
                ensureAuthenticated()
                syncClasses()
                syncHomework()
                syncExams()
                syncStudySessions()
                Log.d(TAG, "All data synced successfully")
            } catch (e: Exception) {
                Log.e(TAG, "Error syncing all data", e)
            }
        }
    }

    private suspend fun ensureAuthenticated() {
        if (auth.currentUser == null) {
            auth.signInAnonymously().await()
            Log.d(TAG, "Anonymous authentication successful")
        }
    }

    private fun syncClasses() {
        serviceScope.launch {
            try {
                val classDao = database.classDao()
                val userId = auth.currentUser?.uid ?: return@launch

                // Upload unsynced classes
                val unsyncedClasses = classDao.getUnsyncedClasses()
                for (classItem in unsyncedClasses) {
                    val docRef = firestore.collection("users")
                        .document(userId)
                        .collection("classes")
                        .document()

                    docRef.set(classItem.copy(cloudId = docRef.id)).await()
                    classDao.updateClass(classItem.copy(syncedToCloud = true, cloudId = docRef.id))
                }

                // Download classes from cloud
                val cloudClasses = firestore.collection("users")
                    .document(userId)
                    .collection("classes")
                    .get()
                    .await()

                for (document in cloudClasses.documents) {
                    val cloudClass = document.toObject(ClassModel::class.java)?.copy(cloudId = document.id)
                    cloudClass?.let {
                        val localClass = classDao.getClassByCloudId(it.cloudId)
                        if (localClass == null) {
                            classDao.insertClass(it.copy(syncedToCloud = true))
                        } else if (it.updatedAt > localClass.updatedAt) {
                            classDao.updateClass(it.copy(id = localClass.id, syncedToCloud = true))
                        }
                    }
                }

                Log.d(TAG, "Classes synced successfully")
            } catch (e: Exception) {
                Log.e(TAG, "Error syncing classes", e)
            }
        }
    }

    private fun syncHomework() {
        serviceScope.launch {
            try {
                val homeworkDao = database.homeworkDao()
                val userId = auth.currentUser?.uid ?: return@launch

                // Upload unsynced homework
                val unsyncedHomework = homeworkDao.getUnsyncedHomework()
                for (homework in unsyncedHomework) {
                    val docRef = firestore.collection("users")
                        .document(userId)
                        .collection("homework")
                        .document()

                    docRef.set(homework.copy(cloudId = docRef.id)).await()
                    homeworkDao.updateHomework(homework.copy(syncedToCloud = true, cloudId = docRef.id))
                }

                // Download homework from cloud
                val cloudHomework = firestore.collection("users")
                    .document(userId)
                    .collection("homework")
                    .get()
                    .await()

                for (document in cloudHomework.documents) {
                    val cloudHomeworkItem = document.toObject(HomeworkModel::class.java)?.copy(cloudId = document.id)
                    cloudHomeworkItem?.let {
                        val localHomework = homeworkDao.getHomeworkByCloudId(it.cloudId)
                        if (localHomework == null) {
                            homeworkDao.insertHomework(it.copy(syncedToCloud = true))
                        } else if (it.updatedAt > localHomework.updatedAt) {
                            homeworkDao.updateHomework(it.copy(id = localHomework.id, syncedToCloud = true))
                        }
                    }
                }

                Log.d(TAG, "Homework synced successfully")
            } catch (e: Exception) {
                Log.e(TAG, "Error syncing homework", e)
            }
        }
    }

    private fun syncExams() {
        serviceScope.launch {
            try {
                val examDao = database.examDao()
                val userId = auth.currentUser?.uid ?: return@launch

                // Upload unsynced exams
                val unsyncedExams = examDao.getUnsyncedExams()
                for (exam in unsyncedExams) {
                    val docRef = firestore.collection("users")
                        .document(userId)
                        .collection("exams")
                        .document()

                    docRef.set(exam.copy(cloudId = docRef.id)).await()
                    examDao.updateExam(exam.copy(syncedToCloud = true, cloudId = docRef.id))
                }

                // Download exams from cloud
                val cloudExams = firestore.collection("users")
                    .document(userId)
                    .collection("exams")
                    .get()
                    .await()

                for (document in cloudExams.documents) {
                    val cloudExam = document.toObject(ExamModel::class.java)?.copy(cloudId = document.id)
                    cloudExam?.let {
                        val localExam = examDao.getExamByCloudId(it.cloudId)
                        if (localExam == null) {
                            examDao.insertExam(it.copy(syncedToCloud = true))
                        } else if (it.updatedAt > localExam.updatedAt) {
                            examDao.updateExam(it.copy(id = localExam.id, syncedToCloud = true))
                        }
                    }
                }

                Log.d(TAG, "Exams synced successfully")
            } catch (e: Exception) {
                Log.e(TAG, "Error syncing exams", e)
            }
        }
    }

    private fun syncStudySessions() {
        serviceScope.launch {
            try {
                val sessionDao = database.studySessionDao()
                val userId = auth.currentUser?.uid ?: return@launch

                // Upload unsynced sessions
                val unsyncedSessions = sessionDao.getUnsyncedSessions()
                for (session in unsyncedSessions) {
                    val docRef = firestore.collection("users")
                        .document(userId)
                        .collection("study_sessions")
                        .document()

                    docRef.set(session.copy(cloudId = docRef.id)).await()
                    sessionDao.updateSession(session.copy(syncedToCloud = true, cloudId = docRef.id))
                }

                // Download sessions from cloud
                val cloudSessions = firestore.collection("users")
                    .document(userId)
                    .collection("study_sessions")
                    .get()
                    .await()

                for (document in cloudSessions.documents) {
                    val cloudSession = document.toObject(StudySessionModel::class.java)?.copy(cloudId = document.id)
                    cloudSession?.let {
                        val localSession = sessionDao.getSessionByCloudId(it.cloudId)
                        if (localSession == null) {
                            sessionDao.insertSession(it.copy(syncedToCloud = true))
                        } else if (it.updatedAt > localSession.updatedAt) {
                            sessionDao.updateSession(it.copy(id = localSession.id, syncedToCloud = true))
                        }
                    }
                }

                Log.d(TAG, "Study sessions synced successfully")
            } catch (e: Exception) {
                Log.e(TAG, "Error syncing study sessions", e)
            }
        }
    }
}
