package com.example.mystudylife.domain.repositories

import com.example.mystudylife.data.models.ClassModel
import kotlinx.coroutines.flow.Flow

interface ClassRepository {
    suspend fun insertClass(classModel: ClassModel): Long
    suspend fun insertClasses(classes: List<ClassModel>)
    fun getAllClasses(): Flow<List<ClassModel>>
    suspend fun getClassById(classId: Int): ClassModel?
    suspend fun getUnsyncedClasses(): List<ClassModel>
    suspend fun updateClass(classModel: ClassModel)
    suspend fun markClassAsSynced(classId: Int, cloudId: String)
    suspend fun deleteClass(classModel: ClassModel)
    suspend fun deleteClassById(classId: Int)
    suspend fun deleteAllClasses()
}
