package com.example.mystudylife.domain.repositories

import com.example.mystudylife.data.models.ExamModel
import kotlinx.coroutines.flow.Flow

interface ExamRepository {
    suspend fun insertExam(examModel: ExamModel): Long
    suspend fun insertExams(exams: List<ExamModel>)
    fun getAllExams(): Flow<List<ExamModel>>
    suspend fun getExamById(examId: Int): ExamModel?
    fun getExamsByClass(classId: Int): Flow<List<ExamModel>>
    fun getExamsByType(examType: String): Flow<List<ExamModel>>
    fun getUpcomingExams(currentTime: Long): Flow<List<ExamModel>>
    fun getPastExams(currentTime: Long): Flow<List<ExamModel>>
    suspend fun getUnsyncedExams(): List<ExamModel>
    suspend fun updateExam(examModel: ExamModel)
    suspend fun updateExamScore(examId: Int, score: Int)
    suspend fun markExamAsSynced(examId: Int, cloudId: String)
    suspend fun deleteExam(examModel: ExamModel)
    suspend fun deleteExamById(examId: Int)
    suspend fun deleteExamsByClass(classId: Int)
    suspend fun deleteAllExams()
}
