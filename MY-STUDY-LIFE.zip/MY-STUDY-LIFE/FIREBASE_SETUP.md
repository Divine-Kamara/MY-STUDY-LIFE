# Firebase Cloud Sync Setup

## Required Setup Steps

1. **Create Firebase Project:**
   - Go to [Firebase Console](https://console.firebase.google.com/)
   - Create a new project called "MY-STUDY-LIFE"

2. **Add Android App:**
   - In Firebase console, click "Add app" → Android
   - Package name: `com.divinemoses.mystudylife`
   - Download `google-services.json`
   - Place it in `app/` directory

3. **Enable Services:**
   - Enable Firestore Database
   - Enable Authentication (Anonymous sign-in)

4. **Firestore Security Rules:**
   ```javascript
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /users/{userId}/{document=**} {
         allow read, write: if request.auth != null && request.auth.uid == userId;
       }
     }
   }
   ```

## Implemented Features

✅ **CloudSyncService** - Handles bidirectional sync with Firestore
✅ **DAO Updates** - Added cloud sync methods to all DAOs
✅ **UI Integration** - Sync button in MainActivity
✅ **Anonymous Auth** - Automatic Firebase authentication
✅ **Conflict Resolution** - Last-write-wins for synced data

## How It Works

- **Upload:** Unsynced local data → Firestore collections
- **Download:** Cloud data → Local database (with conflict resolution)
- **Collections:** `/users/{userId}/classes`, `/homework`, `/exams`, `/study_sessions`
- **Trigger:** Manual sync via "Sync to Cloud" button

## Next Steps

1. Add `google-services.json` to complete Firebase setup
2. Test sync functionality
3. Consider adding sync status indicators
4. Implement automatic sync on app launch/network changes