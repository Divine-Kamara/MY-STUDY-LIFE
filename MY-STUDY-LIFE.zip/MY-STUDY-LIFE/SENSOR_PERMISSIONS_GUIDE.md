# Sensor Permission Handler - MY STUDY LIFE

## Overview
The sensor permission handler manages runtime permissions for device sensors used to track study session quality. This is especially important for Android 12+ where BODY_SENSORS is classified as a dangerous permission.

## Sensors & Permissions

### 1. **Accelerometer** (Motion Sensor)
- **Permission Required:** `BODY_SENSORS`
- **Purpose:** Detects device movement and physical activity
- **Use Case:** Determines focus level (still = focused, shaking = distracted)

### 2. **Light Sensor**
- **Permission Required:** `BODY_SENSORS`
- **Purpose:** Monitors ambient light levels
- **Use Case:** Warns if study environment is too dark or too bright

### 3. **Proximity Sensor**
- **Permission Required:** `BODY_SENSORS`
- **Purpose:** Detects if device is near user's face
- **Use Case:** Tracks active device usage during study sessions

## Android API Level Support

### Android < 12 (API < 31)
- Only requires `BODY_SENSORS` permission
- Permission is classified as "dangerous"
- Must be requested at runtime using `requestPermissions()`

### Android 12+ (API >= 31)
- Requires `BODY_SENSORS` permission (same as before)
- Also supports `BODY_SENSORS_BACKGROUND` for background monitoring
- Both must be granted for full functionality

## Implementation Details

### Key Files
- `utils/PermissionUtils.kt` - Utility methods to check permissions and available sensors
- `utils/SensorPermissionHandler.kt` - Manages permission requests using Activity Result API
- `MainActivity.kt` - Initializes sensor monitoring with permission checks
- `AndroidManifest.xml` - Declares sensor permissions

### Permission Request Flow

```
1. MainActivity.onCreate()
   ↓
2. Check if permissions already granted
   ├─ YES → Initialize sensor monitoring
   └─ NO → Request permissions via SensorPermissionHandler
   ↓
3. User grants/denies permissions
   ├─ GRANTED → Initialize sensor monitoring
   └─ DENIED → Show toast + disable sensor features
```

### Using the Permission Handler

```kotlin
// In your Activity or Fragment
val permissionHandler = SensorPermissionHandler(this)
permissionHandler.setupPermissionLauncher(this)

// Setup callbacks
permissionHandler.onPermissionsGranted = {
    // Sensors initialized
    sensorDataManager.startMonitoring()
}

permissionHandler.onPermissionsDenied = {
    // Handle denied permissions
    Toast.makeText(this, "Sensor permissions denied", Toast.LENGTH_SHORT).show()
}

// Request permissions
permissionHandler.requestSensorPermissions()
```

### Checking Available Sensors

Not all devices have all sensors. Use these utility methods:

```kotlin
PermissionUtils.hasAccelerometer(context) // Returns Boolean
PermissionUtils.hasLightSensor(context)   // Returns Boolean
PermissionUtils.hasProximitySensor(context) // Returns Boolean

// Or get all at once
permissionHandler.areSensorsAvailable() // Returns Map<String, Boolean>
```

## What Happens If Permissions Are Denied?

1. **User denies permissions** → App shows permission dialog
2. **User clicks "Continue Without"** → App runs without sensor features
3. **Sensor data is NOT collected** → Study quality score = 0
4. **User can enable later** → Go to Settings > App > Permissions > Sensors

## Manifest Declarations

```xml
<!-- Required for all Android versions -->
<uses-permission android:name="android.permission.BODY_SENSORS" />

<!-- Optional: Background sensor access (Android 12+) -->
<uses-permission android:name="android.permission.BODY_SENSORS_BACKGROUND" 
    android:maxSdkVersion="33" />

<!-- Sensor features (marked as optional) -->
<uses-feature android:name="android.hardware.sensor.accelerometer" 
    android:required="false" />
<uses-feature android:name="android.hardware.sensor.light" 
    android:required="false" />
<uses-feature android:name="android.hardware.sensor.proximity" 
    android:required="false" />
```

## Best Practices

1. **Always check** if permission is granted before accessing sensors
2. **Request at appropriate time** - Usually on first launch or when entering study mode
3. **Handle gracefully** when sensors are unavailable
4. **Stop monitoring** when app is paused (in onPause())
5. **Resume monitoring** when app is resumed (in onResume())
6. **Show rationale** before requesting permissions

## Testing

To test on different Android versions:
- Android 10-11: Permissions auto-granted on install
- Android 12+: Must request at runtime
- Some emulators don't have all sensors

Check sensor availability:
```kotlin
val available = permissionHandler.areSensorsAvailable()
Log.d("Sensors", available.toString())
```

## Troubleshooting

### Sensors not working?
1. Check if permission is granted: `PermissionUtils.isPermissionGranted(context, BODY_SENSORS)`
2. Check if sensor exists: `PermissionUtils.hasAccelerometer(context)` etc.
3. Check if monitoring is started: `sensorDataManager.startMonitoring()`
4. On Android 12+, ensure both BODY_SENSORS and BODY_SENSORS_BACKGROUND are granted

### Permission dialog not appearing?
1. Ensure you called: `permissionHandler.setupPermissionLauncher(this)`
2. Check if permission is already granted
3. Ensure activity is instance of AppCompatActivity

### Logcat Messages
- "Sensors: HIGH_FOCUS" - User is focused (minimal movement)
- "Sensors: OPTIMAL" - Lighting is optimal
- "Sensors: ACTIVELY_STUDYING" - Device in use
